import java.util.*;
class deleting_eleemnt{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        ArrayList<Integer> list=new ArrayList<>();
        System.out.println("Enter the size :");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elemtns :");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("Emter the elemnts ot be delete: ");
        int delete=Sc.nextInt();

        for(int i=0;i<n;i++){
            list.add(arr[i]);
        }

        list.removeIf(element -> element==delete);

        // list.removeIf(element -> element==delete);
    }
}