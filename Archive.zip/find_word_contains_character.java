import java.util.Scanner;
import java.util.ArrayList;
class find_word_contains_character{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        String arr[]=new String[n];
        System.out.println("Enter the elements: ");
        Sc.nextLine();
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextLine();
           
        }
        System.out.println("Enter the character to check: ");
        char x=Sc.next().charAt(0);
        ArrayList<Integer> list=new ArrayList<>();
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[i].length();j++){
                if(arr[i].charAt(j)==x){
                    list.add(i);
                    break;
                }
            }
        }
        System.out.println(list);
    }
}