import java.util.Scanner;
class accenture_replace{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the rows: ");
        int n=Sc.nextInt();
        System.out.println("Enter the columns: ");
        int n1=Sc.nextInt();
        int arr[][]=new int[n][n1];
        System.out.println("Enter the elements for first matrix: ");
        for(int i=0;i<n;i++){
            for(int j=0;j<n1;j++){
                arr[i][j]=Sc.nextInt();
            }
        }
        int arr1[][]=new int[n][n1];
        for(int i=0;i<n;i++){
            for(int j=0;j<n1;j++){
                arr1[i][j]=arr[j][i];
            }
        }
        int count=0;
        for(int i=0;i<n;i++){
            for(int j=0;j<n1;j++){
                if(arr[i][j]==arr1[i][j]){
                    count++;
                }
            }
        }
        if(count==n*n1){
            System.out.println("teh matrix is symmetric");
        }else{
            System.out.println("Not a symmetric matrix");
        }
    }
}