import java.util.Scanner;
class negative_last{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int last=0;
        for(int i=0;i<n;i++){
            if(arr[i]>=0){
                int temp=arr[i];
                arr[i]=arr[last];
                arr[last]=temp;
                last++;
            }
        }
        System.out.println("the sorted array is: ");
        for(int i=0;i<n;i++){
            System.out.println(arr[i]);
        }
    }
}