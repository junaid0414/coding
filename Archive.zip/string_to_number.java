import java.util.Scanner;
class string_to_number{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the string :");
        String n=Sc.nextLine();
        int number=Integer.parseInt(n.trim());
        System.out.println("string to number is: ");
        System.out.println(number);
    }
}