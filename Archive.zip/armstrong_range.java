import java.util.Scanner;
class armstrong_range{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enetr the first number: ");
        int n1=Sc.nextInt();
        System.out.println("Enetr the second number: ");
        int n2=Sc.nextInt();
        for(int i=n1;i<=n2;i++){
            int temp=i;
            int temp1=i;
            int count=0;
            while(temp!=0){
                int digit=i%10;
                count++;
                temp/=10;
            }
            temp=temp1;
            int sum=0;
            while(temp!=0){
                int digit=temp%10;
                int power=(int)Math.pow(digit, count);
                sum=sum+power;
                temp/=10;
            }
            if(sum==i){
                System.out.println(i);
            }
        }
    }
}




