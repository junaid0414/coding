import java.util.Scanner;
class strong_number{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        int temp=n;
        int sum=0;
        
        while(n!=0){
            int digit=n%10;
            int factorial=1;
            for(int i=1;i<=digit;i++){
                factorial=factorial*i;
            }
            sum=sum+factorial;
            n/=10;
        }
        if(sum==temp){
            System.out.println("strong number");
        }
        else{
            System.out.println("Not a strong number");
        }
    }
}