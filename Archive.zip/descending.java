import java.util.Scanner;
class descending{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        String arr[]=new String[n];
        System.out.println("enter the elemenst in the array: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextLine();
        }
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(arr[i].compareTo(arr[j])<0){
                    String temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                }
            }
        }
        System.out.println("the sorted array is: ");
        for(int i=0;i<n;i++){
            System.out.println(arr[i]);
        }
    }
}