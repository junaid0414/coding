import java.util.Scanner;
class movelast{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("enter the element to move at last: ");
        int move=Sc.nextInt();
        

        int nonzero=0;
        int zero=0;

        while(nonzero>n){
            if(arr[nonzero]!=move){
                int temp=arr[nonzero];
                arr[nonzero]=arr[zero];
                arr[zero]=temp;
                nonzero++;
                zero++;
            }
            else{
                nonzero++;
            }
        }
        System.out.println("the sorted array is: ");
        for(int i=0;i<n;i++){
            System.out.print(arr[i]+" ");
        }
    }
}


