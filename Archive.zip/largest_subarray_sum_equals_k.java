// import java.util.Scanner;
// class largest_subarray_sum_equals_k{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("enter the k value: ");
//         int k=Sc.nextInt();

//         int result=array(arr,n,k);
//         System.out.println("the result is: "+result);
//     }
//     public static int array(int arr[],int n,int k){
//         int l=Integer.MIN_VALUE;
//         for(int i=0;i<n;i++){
//             int sum=0;
//             for(int j=i;j<n;j++){
//                 sum=sum+arr[j];
//                 if(sum==k){
//                 l=Math.max(l,j-i+1);
//                 }
//             }
//         }
//         return l;
//     }
// }








import java.util.Scanner;
class largest_subarray_sum_equals_k{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("enter the k value: ");
        int k=Sc.nextInt();
        int max=Integer.MIN_VALUE;
        for(int i=0;i<n;i++){
            int sum=0;
            for(int j=i;j<n;j++){
                sum=sum+arr[j];
                if(sum==k){
                    int l=j-i+1;
                    if(l>max){
                        max=l;
                    }
                }
            }
        }
        System.out.println(max);
    }
}