import java.util.Scanner;
import java.util.ArrayList;
class add_arraylist{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        ArrayList<Integer> arr=new ArrayList<Integer>();

        System.out.println("enter the list: ");
        arr.add(Sc.nextInt());
        arr.add(Sc.nextInt());
        arr.add(Sc.nextInt());
        arr.add(Sc.nextInt());
        arr.add(Sc.nextInt());

        System.out.println(arr);

        int element=arr.get(4);//it is used to print teh element which is present in the index
        System.out.println("the main element is: "+element);

        //the below line is used is used to insert element  at any position in arraylist
        System.out.println("indert the array index: ");
        int index=Sc.nextInt();
        System.out.println("enter the elements in the array: ");
        int element1=Sc.nextInt();
        arr.add(index,element1);
        System.out.println("the new array is: "+arr);

        
        System.out.println("the new is: ");
        arr.set(0,0);//set function is used to update the element
        System.out.println(arr);


        System.out.println("delete element at specific position: ");
        System.out.println("enter the index to delete element: ");
        int delete=Sc.nextInt();
        arr.remove(delete);
        System.out.println(arr);

        int length=arr.size();
        System.out.println(length);
    }
}