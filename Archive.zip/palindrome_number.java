import java.util.Scanner;
class palindrome_number{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        int original=n;
        int reversed=0;
        while(n>0){
            int digit=n%10;
            reversed=reversed*10+digit;
            n=n/10;
        }
        if(original==reversed){
            System.out.println("palindrome");
        }
        else{
            System.out.println("Not a palindrome");
        }
    }
}