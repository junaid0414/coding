import java.util.Scanner;
public class sum_of_digits_of_string_afterconvert {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("entert eh k value: ");
        int k=Sc.nextInt();
        Sc.nextLine();
        System.out.println("Enter the string :");
        String n=Sc.nextLine();
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<n.length();i++){
            sb.append(n.charAt(i)-'a'+1);
        }
        String con=sb.toString();
        long ans=Integer.parseInt(con);

        for(int i=0;i<k;i++){
            long sum=0;
            while(ans!=0){
                long rem=ans%10;
                sum=sum+rem;
                ans=ans/10;
            }
            ans=sum;
        }

        System.out.println("the last sum is: "+ans);
    }
}

