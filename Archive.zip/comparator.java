// if we want to sort using the last digit of the number then we can use comparator for sorting according to us
// i/p:[12,11,20,19,23]
// o/p:20,11,12,23,19
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
class comparator{
    public static void main(String[] args) {
        Comparator<Integer> com=new Comparator<Integer>(){
            public int compare(Integer i,Integer j){
                if(i%10 > j%10){
                    return 1;
                }
                else{
                    return -1;
                }
            }
        };

        ArrayList<Integer> list=new ArrayList<>();
        list.add(12);
        list.add(21);
        list.add(35);
        list.add(40);
        list.add(59);
        Collections.sort(list,com);
        System.out.println(list);
    }
}













