//subarry sum which equals to target..gfg medium in arrays first question
import java.util.Scanner;
public class return_i_j {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        
        System.out.println("Enter the target: ");
        int target=Sc.nextInt();
        int []result=sub(n,arr,target);
        System.out.println("the result is: "+result[0]+ " "+result[1]);
    }
    public static int[] sub(int n,int arr[],int target){
        for(int i=0;i<n;i++){
            int sum=0;
            for(int j=i;j<n;j++){
                sum=sum+arr[j];
                if(sum==target){
                    return new int[]{i+1,j+1};
                }
            }
        }
        return null;
    }
}
