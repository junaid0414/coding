//370 armstrong
//1634 is armstrong


import java.util.Scanner;
class armstrong{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        int temp=n;
        int temp1=n;
        int count=0;
        while(n!=0){
            int digit=n%10;
            count++;
            n/=10;
        }
        int sum=0;
        while(temp!=0){
            int digit=temp%10;
            int power=(int)Math.pow(digit, count);
            sum=sum+power;
            temp/=10;
        }
        if(sum==temp1){
            System.out.println("armstrong");
        }
        else{
            System.out.println("not a armstrong");
        }
    }
}






