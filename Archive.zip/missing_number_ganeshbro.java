//the below code is method1

import java.util.Scanner;
class missing_number_ganeshbro{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n1=Sc.nextInt();
        int arr[]=new int[n1];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n1;i++){
            arr[i]=Sc.nextInt();
        }

        int max=arr[0];
        int min=arr[0];
        for(int i=1;i<n1;i++){
            if(arr[i]>max){
                max=arr[i];
            }
            else if(arr[i]<min){
                min=arr[i];
            }
        }

        int n=(max-min)+1;
        int formula=n/2*((2*n1)+(n-1)*1);  //this formula is n/2(2a+(n-1)d); 
                                                                // n=(max-min)+1
                                                                // a=length.array
                                                                // d=1
        int sum=0;
        for(int i=0;i<n1;i++){
            sum=sum+arr[i];
        }
        int result=formula-sum;

        System.out.println("the result is: "+result);
    }
}






// the below code is method:2 


// import java.util.Scanner;
// import java.util.HashSet;
// class missing_number_ganeshbro{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n1=Sc.nextInt();
//         int arr[]=new int[n1];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n1;i++){
//             arr[i]=Sc.nextInt();
//         }

//         int max=arr[0];
//         int min=arr[0];
//         for(int i=1;i<n1;i++){
//             if(arr[i]>max){
//                 max=arr[i];
//             }
//             else if(arr[i]<min){
//                 min=arr[i];
//             }
//         }

//         HashSet<Integer> set=new HashSet<>();
//         for(int i=0;i<n1;i++){
//             set.add(arr[i]);
//         }
//         for(int i=min;i<=max;i++){
//             if(!set.contains(i)){
//                 System.out.println("hi "+i);
//                 break;
//             }
//         }
//     }
// }
