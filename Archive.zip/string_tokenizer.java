import java.util.*;
import java.util.StringTokenizer;
class string_tokenizer{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");;
        String n=Sc.nextLine();
        StringTokenizer sb=new StringTokenizer(n);
        int count=0;
        while(sb.hasMoreTokens()){
            
            count++;
        }
        System.out.println(count);
    }
}