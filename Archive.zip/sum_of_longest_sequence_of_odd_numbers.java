
import java.util.Scanner;
class sum_of_longest_sequence_of_odd_numbers{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elementz: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int max=Integer.MIN_VALUE;
        int count=0;
        int sum=0;
        for(int i=0;i<n;i++){
            if(arr[i]%2!=0){
                count++;
                sum=sum+arr[i];
            }
            if(sum>max){
                max=sum;
            }
        }
    }
}