// import java.util.Scanner;
// class peak{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the array size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         int lastele=-1;
//         for(int i=1;i<n-1;i++){
//             if(arr[i-1]<arr[i] && arr[i+1]<arr[i]){
//                 lastele=arr[i];
//             }
//         }
//         if(lastele!=-1){
//             System.out.println(lastele);
//         }
//         else{
//             System.out.println("element is not found");
//         }
//     }
// }

