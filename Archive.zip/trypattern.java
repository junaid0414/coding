import java.util.Scanner;
public class trypattern {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the rows: ");
        int n=Sc.nextInt();
        System.out.println("Enter the columns: ");
        int n1=Sc.nextInt();

        for(int i=0;i<n;i++){
            if(i==0){
                for(int j=0;j<5;j++){
                    System.out.print(n1+ "   ");
                }
            }
            else if(i==1){
                for(int j=0;j<5;j++){
                    if(j==0 || j==4){
                        System.out.print(n1+"   ");
                    }
                    else{
                        System.out.print((n1-1)+"   ");
                    }
                }
            }
            System.out.println();
        }
        
    }
}





