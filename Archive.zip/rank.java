// import java.util.*;
// class rank{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enetr the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         int rank[]=new int[n];
//         for(int i=0;i<n;i++){
//             rank[i]=arr[i];
//         }
//         Arrays.sort(rank);
//         HashMap<Integer,Integer> map=new HashMap<>();
//         for(int i=0;i<n;i++){
//             if(!map.containsKey(rank[i])){
//                 map.put(rank[i],i+1);
//             }
//         }
//         int ans[]=new int[n];
//         for(int i=0;i<n;i++){
//             ans[i]=map.get(arr[i]);
//         }

//         for(int key:ans){
//             System.out.print(key+"  ");
//         }
//     }
// }







import java.util.*;

class rank {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the size of the array: ");
        int n = sc.nextInt();
        
        int arr[] = new int[n];
        System.out.println("Enter the elements: ");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        
        // Copy original array to rank array
        int rank[] = new int[n];
        for (int i = 0; i < n; i++) {
            rank[i] = arr[i];
        }

        // Sort the rank array
        Arrays.sort(rank);

        // Create a map to store ranks
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < n; i++) {
            if (!map.containsKey(rank[i])) {
                map.put(rank[i], i + 1);  // Store rank starting from 1
            }
        }

        // Create result array to store the ranks for original elements
        int ans[] = new int[n];
        for (int i = 0; i < n; i++) {
            ans[i] = map.get(arr[i]);  // Directly access rank using the original array element
        }

        // Print the ranks
        System.out.println("Ranks:");
        for (int rankValue : ans) {
            System.out.print(rankValue + " ");
        }
    }
}
