import java.util.Scanner;
class hussain{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }     
        System.out.println("enter the r value: ");
        int r=Sc.nextInt();
        System.out.println("enter the unit value :");
        int value=Sc.nextInt();
        int z=r*value;
        System.out.println(z);

        int q=r-value;
        System.out.println("the q value is: ");
        System.out.println(q);

        int sum=0;
        for(int i=0;i<q-1;i++){
            sum=sum+arr[i];
        }
        System.out.println("the sum value is: "+sum);
    }
}

