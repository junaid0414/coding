// import java.util.Scanner;
// import java.util.HashMap;
// import java.util.TreeMap;
// class accenture_convoy{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }    
//         System.out.println("Enter the size: ");
//         int n1=Sc.nextInt();
//         int arr1[]=new int[n1];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n1;i++){
//             arr1[i]=Sc.nextInt();
//         }

//         TreeMap<Integer,Integer>map=new TreeMap<>();
//         for(int i=0;i<n;i++){
//             if(map.containsKey(arr[i])){
//                 map.put(arr[i],map.get(arr[i])+1);
//             }
//             else{
//                 map.put(arr[i],1);
//             }
//         }
//         System.out.println(map);
//     }
// }




// import java.util.Scanner;
// class accenture_convoy{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }   
//         System.out.println("Enter the s value: ");
//         int s=Sc.nextInt(); 
//         int sum=0;
//         int length=0;
//         int count=0;
//         for(int i=0;i<n;i++){
//             for(int j=i;j<n;j++){
//                 sum=arr[i]+arr[j];
//                 if(sum>=s){
//                     count++;
//                 }
//                 length=j-i+1;

//             }
//         }
//         System.out.println(count);
//     }
// }





