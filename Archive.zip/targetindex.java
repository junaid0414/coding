// import java.util.Scanner;
// class targetindex{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the array size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements in the array: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("enter the search element: ");
//         int search=Sc.nextInt();
//         int index=0;
//         for(int i=0;i<n;i++){
//             if(arr[i]==search){
//                 index=i;
//             }
//         }
//         System.out.println("the element found at the index: "+index);

//     }
// }




import java.util.Scanner;
class targetindex{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        int n=Sc.nextInt();
        int flag=0;
        int arr[]=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int n1=Sc.nextInt();
        int index=0;
        for(int i=0;i<n;i++){
            if(arr[i]==n1){
                index=i;
                flag=1;
            }
        }
        if(flag==1)
        {
            System.out.println(index);
        }
        else
        System.out.println("-1");
    }
}