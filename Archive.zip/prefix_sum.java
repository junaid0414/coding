import java.util.Scanner;
class prefix_sum{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int prefix[]=new int[n];

        prefix[0]=arr[0];
        for(int i=1;i<n;i++){
            prefix[i]=prefix[i-1]+arr[i];
        }

        System.out.println("The prefix sum is: ");
        for(int i=0;i<n;i++){
            System.out.println(prefix[i]);
        }
    }
}