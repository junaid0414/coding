import java.util.Scanner;
class split{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        //the below line for ignoring spaces instead of " " this we can keep \\s
        String arr[]=n.split(" ");
        for(int i=arr.length-1;i>=0;i--){
            System.out.println(arr[i]);
        }
    }
}