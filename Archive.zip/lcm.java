// import java.util.Scanner;
// class lcm{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the first number: ");
//         int n1=Sc.nextInt();
//         System.out.println("Enter the seocnd number :");
//         int n2=Sc.nextInt();

//         int lcm=0;
//         int max=0;
//         if(n1>n2){
//             max=n1;
//         }
//         else{
//             max=n2;
//         }
//         for(int i=max;i<(n1*n2);i++){
//             if(i%n1==0 && i%n2==0){
//                 lcm=i;
//                 break;
//             }
//         }
//         System.out.println("the lacm is: "+lcm);
//     }
// }







