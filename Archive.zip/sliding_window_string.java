import java.util.Scanner;
class sliding_window_string{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();

        System.out.println("Enter the k value: ");
        int k=Sc.nextInt();

        int count=0;
        int max=0;
        for(int i=0;i<k;i++){
            char sum=n.charAt(i);
            if(sum=='a' || sum=='e' || sum=='i' || sum=='o' || sum=='u'){
                count++;
            }
        }
        if(count>max){
            max=count;
        }

        char arr[]=n.toCharArray();
        String window="";
        for(int i=k;i<=n.length()-1;i++){
            count=0;
            window=windowarr[i-k]+arr[i];
            char ch=window.charAt(i);
            if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u'){
                count++;
            }
            if(count>max){
                max=count;
            }
        }
        System.out.println(count);
    }
}