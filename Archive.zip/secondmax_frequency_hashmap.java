import java.util.Scanner;
import java.util.HashMap;
class secondmax_frequency_hashmap{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        String n=Sc.nextLine();
        char arr[]=n.toCharArray();
        HashMap<Character,Integer> map=new HashMap<>();
        for(char key:arr){
            map.put(key,map.getOrDefault(key,0)+1);
        }
        int max=Integer.MIN_VALUE;
        for(int key:map.values()){
            if(key>max){
                max=key;
            }
        }
        int secondmax=Integer.MIN_VALUE;
        for(int key:map.values()){
            if(key>secondmax && key<max){
                secondmax=key;
            }
        }
        if(secondmax==Integer.MIN_VALUE){
            System.out.println("not found any second max");
        }
        else{
            System.out.println(secondmax);
        }
    }
}