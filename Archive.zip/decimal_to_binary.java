import java.util.Scanner;
class decimal_to_binary{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        String z="";
        int n1=n;
        while(n1!=0){
            int rem=n1%2;
            z=rem+z;
            n1/=2;
        }
        System.out.println("the z is: "+z);
    }
}