//program from userinput
import java.util.Scanner;
class problem5{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array blocks: ");
        int n=Sc.nextInt();
        System.out.println("enter the number of elements: ");
        int number[]=new int[n];

        //input
        for(int i=0;i<n;i++){
            number[i]=Sc.nextInt();
        }

        //output
        System.out.println("the output is: ");
        for(int j=0;j<n;j++){
            System.out.println(number[j]);
        }
        Sc.close();
    
    }
}