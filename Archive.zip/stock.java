// method 1
// import java.util.Scanner;
// class stock{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enetr the array size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         int result=stock(n,arr);
//         System.out.println("the result is: "+result);
//     }
//     public static int stock(int n,int arr[]){
//         int max=0;
//         int min=Integer.MAX_VALUE;
//         for(int i=0;i<n;i++){
//             if(arr[i]<min){
//                 min=arr[i];
//             }
//             else if(arr[i]-min>max){
//                 max=arr[i]-min;
//             }
//         }
//         return max;
//     }
// }






//method 2
// import java.util.Scanner;
// class stock{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         int mini=arr[0];
//         int profit=0;
//         for(int i=1;i<n;i++){
//             int cost=arr[i]-mini;
//             profit=Math.max(cost,profit);
//             mini=Math.min(mini,arr[i]);
//         }
//         System.out.println(profit);
//     }
// }







import java.util.Scanner;
class stock{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int mini=arr[0];
        int profit=0;
        for(int i=1;i<n;i++){
            int cost=arr[i]-mini;
            if(cost>profit){
                profit=cost;
            }
            if(arr[i]<mini){
                mini=arr[i];
            }
        }
        System.out.println("the profit is: "+profit);
    }
}