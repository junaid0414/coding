import java.util.Scanner;
class tcs_may_eight_slot_two{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elementS: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        for(int i=0;i<n;i++){
            if(arr[i]%3==0 && arr[i]%5==0){
                System.out.println("ThreeFive");
            }
            else if(arr[i]%3==0){
                System.out.println("Three");
            }
            else if(arr[i]%5==0){
                System.out.println("Five");
            }
            else{
                System.out.println(arr[i]);
            }
        }
    }
}