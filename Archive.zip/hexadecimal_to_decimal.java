import java.util.Scanner;
class hexadecimal_to_decimal{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();

        int decimal=Integer.parseInt(n,16);
        System.out.println("the decimal number is: "+decimal);
    }
}