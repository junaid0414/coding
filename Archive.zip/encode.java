// import java.util.Scanner;
// class encode{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the String: ");
//         String n=Sc.nextLine();
//         StringBuilder sb=new StringBuilder();

//         int count=1;
//         for(int i=1;i<n.length();i++){
//             if(n.charAt(i)==n.charAt(i-1)){
//                 count++;
//             }
//             else{
//                 sb.append(n.charAt(i-1)).append(count);
//                 count=1;
//             }
//         }
//         sb.append(n.charAt(n.length()-1)).append(count);
//         System.out.println(sb.toString());
//     }
// }










import java.util.Scanner;
class encode{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enetr the string: ");
        String n=Sc.nextLine();

        int count=1;
        StringBuilder sb=new StringBuilder();
        for(int i=1;i<n.length();i++){
            if(n.charAt(i)==n.charAt(i-1)){
                count++;
            }
            else{
                sb.append(n.charAt(i-1));
                sb.append(count);
                count=1;
            }
        }
        sb.append(n.charAt(n.length()-1));
        System.out.println(sb.toString());
    }
}