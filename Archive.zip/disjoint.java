import java.util.Scanner;
class disjoint{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int arr1[]=new int[n];
        System.out.println("enetr the elements in the array :");
        for(int i=0;i<n;i++){
            arr1[i]=Sc.nextInt();
        }
        System.out.println("enter the array size: ");
        int n1=Sc.nextInt();
        int arr2[]=new int[n1];
        System.out.println("enetr the elements in the array :");
        for(int i=0;i<n1;i++){
            arr2[i]=Sc.nextInt();
        }
        for(int i=0;i<n;i++){
            for(int j=0;j<n1;j++){
                if(arr1[i]==arr2[i]){
                    System.out.println("yes");
                    return;
                }
            }
        }
        System.out.println("No");
    }
}