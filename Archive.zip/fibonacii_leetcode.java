import java.util.Scanner;
class fibonacii_leetcode{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();

        int result=result(n);
        System.out.println("the result is: "+result);
    }
    public static int result(int n){
        int a=0;
        int b=1;
        for(int i=2;i<=n;i++){
            int c=a+b;
            a=b;
            b=c;
        }
        return b;
    }
}