import java.util.Scanner;
import java.util.HashSet;
class missingnumber_array{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Ente rthe size :");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the eleemnts: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        HashSet<Integer> set=new HashSet<>();
        for(int key:arr){
            set.add(key);
        }
        for(int i=1;i<=arr.length;i++){
            if(!set.contains(i)){
                System.out.println(i);
            }
        }
    }
}