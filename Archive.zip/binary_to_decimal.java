// import java.util.Scanner;
// class binary_to_decimal{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the binary number: ");
//         int binary=Sc.nextInt();

//         int temp=binary;
//         int power=0;
//         int sum=0;
//         while(temp!=0){
//             int digit=temp%10;
//             int ans=digit*(int)Math.pow(2,power);
//             sum=sum+ans;
//             temp/=10;
//             power++;
//         }
//         System.out.println(sum);
//     }
// }




