//O(n2)
//this is without using stack

import java.util.Scanner;
class next_greater{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter teh size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        for(int i=0;i<n;i++){
            boolean flag=false;
            for(int j=i+1;j<n;j++){
                if(arr[j]>arr[i]){
                    System.out.println(arr[j]+" ");
                    flag=true;
                    break;
                }
            }
            if(flag==false){
                System.out.println("-");
            }
        }
    }
}



