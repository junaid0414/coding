import java.util.Scanner;
import java.util.HashSet;
import java.util.Iterator;
class union_of_two_arrays{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        HashSet <Integer> arr=new HashSet<Integer>();
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            int ele=Sc.nextInt();
            arr.add(ele);
        }

        HashSet <Integer> arr1=new HashSet<>();
        System.out.println("enter the size: ");
        int n1=Sc.nextInt();
        System.out.println("enter the elemnts: ");
        for(int i=0;i<n1;i++){
            int ele1=Sc.nextInt();
            arr.add(ele1);
        }
        arr.addAll(arr1);

        System.out.println("the merged array is: ");
        Iterator it=arr.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }
}