import java.util.Scanner;
import java.util.ArrayList;
import java.util.Stack;
class reverse_first_k_characters{
    public static void main(String[] args) {
        ArrayList<Character> list=new ArrayList<>();

        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        System.out.println("Enter the k value : ");
        int k=Sc.nextInt();
        for(int i=0;i<k;i++){
            list.add(n.charAt(i));
        }
        Stack<Character> stack=new Stack<>();
        while(!list.isEmpty()){
            stack.push(list.remove(0));
        }
        StringBuilder sb=new StringBuilder();
        while(!stack.isEmpty()){
            sb.append(stack.pop());
        }
        for(int i=k;i<n.length();i++){
            sb.append(n.charAt(i));
        }
        System.out.println(sb);
    }
}