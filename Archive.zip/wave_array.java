import java.util.Scanner;
class wave_array{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the sieze: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("eleemts: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        for(int i=0;i<n-1;i=i+2){
            int temp=arr[i];
            arr[i]=arr[i+1];
            arr[i+1]=temp;
        }
        System.out.println("the soertdfr is :");
        for(int i=0;i<n;i++){
            System.out.println(arr[i]);
        }
    }
}