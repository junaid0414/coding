// Input1: 3
// input2: (4,5,7}
// input3: (7,6,7}
// Output: 3
// Explanation: Here the given array A is (4,5,7) and C is {7,6,7). The seating arrangements of the team members would be like:
// • The first 7 people, will sit in a seven seater car.
// • Now, out of the 9 (4+5) remaining people, 7 people will sit in another 7 seater car.
// • Now, remaining 2 people will sit in a 6 seater car.

// The total cars required is 3. Hence, 3 is returned as output.
import java.util.*;
class cognizant_seats{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int persons[]=new int[n];
        int cars[]=new int[n];
        System.out.println("Enter the persons: ");
        for(int i=0;i<n;i++){
            persons[i]=Sc.nextInt();
        }
        System.out.println("Enter the cars seatings: ");
        for(int i=0;i<n;i++){
            cars[i]=Sc.nextInt();
        }
        
        int sum=0;
        for(int key:persons){
            sum=sum+key;
        }

        Arrays.sort(cars);
        int count=0;
        for(int i=n-1;i>=0;i--){
            if(sum<=0)
            break;
            sum-=cars[i];
            count++;
        }
        System.out.println("the count is: "+count);
    }
}

