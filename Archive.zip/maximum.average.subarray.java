// Input: nums = [1,12,-5,-6,50,3], k = 4
// Output: 12.75000
// Explanation: Maximum average is (12 - 5 - 6 + 50) / 4 = 51 / 4 = 12.75
// Example 2:

// Input: nums = [5], k = 1
// Output: 5.00000
    
 import java.util.Scanner;
 class maximum.average.subarray{
     public static double array(int arr[],int n,int k){
         int sum=0;
         for(int i=0;i<k;i++){
             sum=sum+arr[i];
         }
         double max=Double.MIN_VALUE;
         for(int i=k;i<arr.length;i++){
             sum=sum-arr[i-k]+arr[i];
             double q=sum/(double)k;
             if(q>max){
                 max=q;
             }
         }
         return max;
     }
     public static void main(String[] args) {
         Scanner Sc=new Scanner(System.in);
         System.out.println("enter the size: ");
         int n=Sc.nextInt();
         int arr[]=new int[n];
         System.out.println("enter the elements: ");
         for(int i=0;i<n;i++){
             arr[i]=Sc.nextInt();
         }
         System.out.println("enter teh k value: ");
         int k=Sc.nextInt();
         double result=array(arr,n,k);
         System.out.println(result);
     }
 }
