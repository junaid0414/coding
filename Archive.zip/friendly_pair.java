import java.util.Scanner;
class friendly_pair{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the first number: ");
        int n1=Sc.nextInt();
        System.out.println("Enter the second number: ");
        int n2=Sc.nextInt();

        int sum=0;
        for(int i=1;i<n1;i++){
            if(n1%i==0){
                sum=sum+i;
            }
        }

        int sum1=0;
        for(int i=1;i<n2;i++){
            if(n2%i==0){
                sum1=sum1+i;
            }
        }

        if(sum/n1 == sum1/n2){
            System.out.println("friendly pair");
        }
        else{
            System.out.println("Not a friendly pair");
        }
    }
}