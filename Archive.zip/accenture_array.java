// import java.util.Scanner;
// import java.util.ArrayList;
// import java.util.Collections;
// class accenture_array{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         int result=array(n,arr);
//         System.out.println("The result is: "+result);
//     }
//     public static int array(int n,int arr[]){
//         ArrayList<Integer> list1=new ArrayList<Integer>();
//         ArrayList<Integer> list2=new ArrayList<>();
        
//         for(int i=0;i<n;i++){
//             if(i%2==0){
//                 list1.add(arr[i]);
//             }
//             else{
//                 list2.add(arr[i]);
//             }
//         }
//         Collections.sort(list1);
//         Collections.sort(list2,Collections.reverseOrder());
        
//         int one=0;
//         int sec=0;
        
//         for(int i=0;i<list1.size();i++){
//             if(list1.size()==1){
//                 one=list1.get(0);
//             }
//             else{
//             one =list1.get(1);
//             }
//         }
//         for(int i=0;i<list2.get(i);i++){
//             if(list2.size()==1){
//                 one=list2.get(0);
//             }
//             else{
//             one =list2.get(1);
//             }
//         }
        
//         return one+sec;
//     }
    
// }







import java.util.Scanner;
class accenture_array{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int min=Integer.MAX_VALUE;
        int mul=1;
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(arr[i]+arr[j]<=min){
                    min=arr[i]+arr[j];
                    mul=arr[i]*arr[j];
                }
            }
        }
        System.out.println(mul+" is");
    }
}