import java.util.Scanner;
import java.util.ArrayList;
import java.util.Queue;
import java.util.LinkedList;
class amazon{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array list: ");
        int n=Sc.nextInt();
        System.out.println("enter the elements: ");
        ArrayList<Integer> list=new ArrayList<Integer>();
        for(int i=0;i<n;i++){
            int ele=Sc.nextInt();
            list.add(ele);
        }

        System.out.println("enter the array list: ");
        int n1=Sc.nextInt();
        System.out.println("enter the elements: ");
        ArrayList<Integer> items=new ArrayList<Integer>();
        for(int i=0;i<n1;i++){
            int ele1=Sc.nextInt();
            items.add(ele1);
        }
        
        Queue<Integer> cart=new LinkedList<>();
        for(int i=0;i<n;i++){
            cart.add(list.get(i));
        }

        Queue<Integer> store =new LinkedList<>();

        for(int i=0;i<n1;i++){
            if(items.get(i)+cart.peek()==0){
                cart.remove();
            }
            else if(items.get(i)>=0){
                cart.add(items.get(i));
            }
            else if(items.get(i)!=cart.peek()){
                store.add(cart.peek());
            }
        }
        System.out.println(cart);
    }
}
































// import java.util.Scanner;
// import java.util.ArrayList;
// import java.util.Queue;
// import java.util.LinkedList;
// import java.util.Iterator;
// class amazon{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the size: ");
//         int n=Sc.nextInt();
//         System.out.println("Enter the elements: ");
//         ArrayList<Integer> list=new ArrayList<Integer>();
//         for(int i=0;i<n;i++){
//             int ele=Sc.nextInt();
//             list.add(ele);
//         }
//         System.out.println("enter the size: ");
//         int n1=Sc.nextInt();
//         System.out.println("enter the elements: ");
//         ArrayList<Integer> list1=new ArrayList<>();
//         for(int i=0;i<n1;i++){
//             int ele1=Sc.nextInt();
//             list1.add(ele1);
//         }
//         Queue<Integer> q = new LinkedList<>();
//         for(int i=0;i<n;i++){
//             q.add(list.get(i));
//         }
//         for(int i=0;i<q.size();i++){
//             for(int j=0;j<n1;j++){
//                 if(list1.get(i)+q.get(i)==0){
//                     q.remove();
//                     break;
//                 }
//             }
//         }
//         System.out.println("the q is: ");
//         System.out.println(q.get(i));
//     }
// }