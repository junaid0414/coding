import java.util.Scanner;
class occcurences{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int i=1;
        int count=1;
        while(i<arr.length){
            if(i<arr.length && arr[i]==arr[i-1]){
                count++;
                i++;
            }
            System.out.println(arr[i-1]+" "+count);
            count=1;
            i++;
        }
    }
}