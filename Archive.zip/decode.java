import java.util.Scanner;
class decode{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter teh string: ");
        String n=Sc.nextLine();
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<n.length();i=i+2){
            char letter=n.charAt(i);
            int num=n.charAt(i+1)-'0';
            for(int j=0;j<num;j++){
                sb.append(letter);
            }
        }
        System.out.println(sb.toString());
    }
}