import java.util.Scanner;
class accenture_bitwise{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enetr the string :");
        String n=Sc.nextLine();

        int result=n.charAt(0)-'0';

        for(int i=1;i<n.length();i=i+2){
            char operator=n.charAt(i);
            int num=n.charAt(i+1)-'0';

            if(operator=='A'){
                result=result&num;
            }
            else if(operator=='B'){
                result=result|num;
            }
            else{
                result=result^num;
            }
        }
        System.out.println("the result is: "+result);
    }
}