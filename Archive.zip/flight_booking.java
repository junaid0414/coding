import java.util.Scanner;
class flight_booking{
    public static void main(String args[]) {
        Scanner Sc = new Scanner(System.in);
        int option = 0;

        String name = "@", flightnumber = "@", city = "@", destination = "@", date = "@";
        while (option != 4) {
            System.out.println("1. Booking a flight");
            System.out.println("2. view bookings");
            System.out.println("3. canel bookings");
            System.out.println("4.exit");
            System.out.println("Enter the option: ");
            option = Sc.nextInt();
            switch (option) {
                case 1:
                    Sc.nextLine();
                    System.out.println("Enter the passenger name: ");
                    name = Sc.nextLine();
                    System.out.println("Enter the flight number: ");
                    flightnumber = Sc.nextLine();
                    System.out.println("Enter the departure city: ");
                    city = Sc.nextLine();
                    System.out.println("Enter the destination city: ");
                    destination = Sc.nextLine();
                    System.out.println("Enter the date of travel: (DD-MM-YYYY)");
                    date = Sc.nextLine();

                    System.out.println("Flight booked Sucessfully 🙏");
                    break;

                case 2:
                    System.out.println("Passenger name is: " + name);
                    System.out.println("passenger bookings: ");
                    System.out.println("flight number: " + flightnumber);
                    System.out.println("departure city: " + city);
                    System.out.println("destinations city: " + destination);
                    System.out.println("Date of the flight is: " + date);
                    break;

                case 3:
                    System.out.println("Passenger name is: " + name);
                    System.out.println("Enter the flight number to cancel: ");
                    String cancel=Sc.nextLine();
                    if(flightnumber.equals(cancel)){
                        System.out.println("Booking sucessfully cancelled");
                    }
                    else{
                        System.out.println("No such booking found !");
                    }
                    break;

                case 4:
                    System.out.println("Tahnks for reaching us");
                    break;

                default:
                    System.out.println("Invalid option");
            }
        }
    }
}