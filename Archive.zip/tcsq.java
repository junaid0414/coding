import java.util.*;
public class tcsq {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        int n=Sc.nextInt();
        int arr[]=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("enter the k value: ");
        int k=Sc.nextInt();
        for(int i=0;i<n;i++){
            int sum=0;
            for(int j=i;j<n;j++){
                sum=sum+arr[j];
                if(sum==k){
                    System.out.println((i+1)+"  "+(j+1));
                    return;
                }
            }
        }
    }
}

// i
// 5   3   7   14   18   1   18   4   8   3
//     j