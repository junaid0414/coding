import java.util.Scanner;
class prime_factors{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        int i=2;
        while(n>1){
            while(n%i==0){
                System.out.println(i);
                n=n/i;
            }
            i++;
        }
    }
}