import java.util.Scanner;
import java.util.ArrayList;
public class longest_substring_without_repeating_characters {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        int start=0;
        int end=0;
        int max=0;
        ArrayList<Character> list=new ArrayList<Character>();
        while(end<n.length()){
            if(!list.contains(n.charAt(end))){
                list.add(n.charAt(end));
                end++;
                max=Math.max(max,list.size());
            }
            else{
                list.remove(Character.valueOf(n.charAt(start)));
                start++;
            }
        }
        System.out.println(max);
    }
}
