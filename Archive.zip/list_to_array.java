import java.util.Scanner;
import java.util.ArrayList;
class list_to_array{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        ArrayList<Integer> list=new ArrayList<>();
        for(int i=0;i<n;i++){
            int ele=Sc.nextInt();
            list.add(ele);
        }
        int arr[]=new int[list.size()];
        for(int k=0;k<list.size();k++){
            arr[k]=list.get(k);
        }
        for(int i=0;i<arr.length;i++){
            System.out.println(arr[i]);
        }
    }
}