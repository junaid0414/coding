// n!/(n-p)!
import java.util.Scanner;
class permutations{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the n value: ");
        int n=Sc.nextInt();
        System.out.println("Enter the p vaule: ");
        int p=Sc.nextInt();

        int fact1=1;
        for(int i=1;i<=n;i++){
            fact1=fact1*i;
        }

        int ans=n-p;
        int fact2=1;
        for(int i=1;i<=ans;i++){
            fact2=fact2*i;
        }
        int ans1=fact1/fact2;
        System.out.println(ans1);
    }
}