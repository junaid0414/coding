import java.util.Scanner;
class distance_between_two_numbers{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("enter the x value: ");
        int x=Sc.nextInt();
        System.out.println("enter the y value: ");
        int y=Sc.nextInt();
        int z=0;
        int count=0;
        for(int i=0;i<n;i++){
            if(arr[i]==x && arr[i]==y){
                z=arr[y]-arr[x];
                count++;
            }
            // else{
            //     System.out.println("-1");
            //     break;
            // }
        }
        if(count==0){
            System.out.println("-1");
        }
        System.out.println(z);
    }
}