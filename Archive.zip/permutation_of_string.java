// import java.util.Scanner;
// class permutation_of_string{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the string: ");
//         String n=Sc.nextLine();

//         dfs(n,"");
//     }
//     public static void dfs(String n,String perm){
//         if(n.length()==0){
//             System.out.println(perm);
//             return;
//         }

//         for(int i=0;i<n.length();i++){
//             char ch=n.charAt(i);

//             String newstr=n.substring(0,i)+n.substring(i+1);

//             dfs(newstr,perm+ch);
//         }
//     }
// }








