// import java.util.Scanner;
// class subarray{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements in the array: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         for(int i=0;i<n;i++){
//             for(int j=i;j<n;j++){
//                 for(int k=i;k<=j;k++){
//                     System.out.print(arr[k]+" ");
//                 }
//                 System.out.println();
//             }
//         }
//     }
// }





// import java.util.Scanner;
// class subarray{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the string: ");
//         String n=Sc.nextLine();
//         char arr[]=n.toCharArray();
//         StringBuilder sb=new StringBuilder();
//         for(int i=0;i<n.length();i++){
//             for(int j=i+1;j<=n.length();j++){
//                 sb.append(n.substring(i,j));
//                 System.out.println(sb.toString());
//                 sb.setLength(0);
//             }
//         }
//     }
// }






import java.util.Scanner;

class subarray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n = sc.nextLine();
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < n.length(); i++) {
            for (int j = i + 1; j <= n.length(); j++) {
                sb.append(n.substring(i, j));
                String substring = sb.toString();
                int length = substring.length();
                System.out.println("Substring: " + substring + ", Length: " + length);
                sb.setLength(0); // Reset the StringBuilder after each substring
            }
        }
    }
}
