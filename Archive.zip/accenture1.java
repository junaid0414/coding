// You have been given an array of integers. Your task is to write a program to sort the elements such that all even elements appear first, followed by all odd elements, while maintaining the relative order of even and odd elements. Implement the sorting algorithm in-place.
import java.util.ArrayList;
import java.util.Scanner;
class accenture1{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        ArrayList<Integer> hi=new ArrayList<Integer>();
        ArrayList<Integer> hl=new ArrayList<Integer>();
        ArrayList<Integer> lk=new ArrayList<Integer>();
        for(int i=0;i<n;i++){
            if(arr[i]%2==0){
                hi.add(arr[i]);
            }
            else{
                hl.add(arr[i]);
            }
        }
        for(int i=0;i<hi.size();i++){
            lk.add(hi.get(i));
        }
        for(int i=0;i<hl.size();i++){
            lk.add(hl.get(i));
        }
        System.out.println("the array is: "+lk);
    }
}