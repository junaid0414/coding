import java.util.Scanner;
class octal_to_decimal{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int octal=Sc.nextInt();

        int temp=octal;
        int power=0;
        int sum=0;
        while(temp!=0){
            int digit=temp%10;
            int ans=digit*(int)Math.pow(8,power);
            sum=sum+ans;
            temp/=10;
            power++;
        }
        System.out.println(sum);
    }
}