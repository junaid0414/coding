// time complexity=0(n)
// spcae complexity =0(1)

import java.util.Scanner;
class product_of_subarray_optimised{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int max=Integer.MIN_VALUE;
        int pro=1;

        for(int i=0;i<n;i++){
            pro=pro*arr[i];
            if(pro>max){
                max=pro;
            }
            if(arr[i]==0){
                pro=1;
            }
        }

        pro=1;
        for(int i=n-1;i>=0;i--){
            pro=pro*arr[i];
        
        if(pro>max){
            max=pro;
        }
        if(arr[i]==0){
            pro=1;
        }
    }

        System.out.println(max);;
    }
}