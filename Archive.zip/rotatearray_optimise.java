import java.util.Scanner;
class rotatearray_optimise{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("Enter the rotations: ");
        int rotations=Sc.nextInt();

        rotate(n,arr,rotations);
        for(int i=0;i<n;i++){
            System.out.println(arr[i]+" ");
        }
      
    }
    static void rotate(int n,int arr[],int rotations){
        rotations=rotations%n;
        if(rotations<0){
            rotations=rotations+n;
        }
        reverse(arr,0,rotations-1);
        reverse(arr,rotations,n-1);
        reverse(arr,0,n-1);

    }
    static void reverse(int arr[],int start,int end){
        while(start<end){
            int temp=arr[start];
            arr[start]=arr[end];
            arr[end]=temp;
            start++;
            end--;
        }
    }
}