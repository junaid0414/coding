import java.util.Scanner;

class ascending {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the array size: ");
        int n = sc.nextInt();
        String arr[] = new String[n];
        System.out.println("Enter the elements in the array: ");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.next(); // Use next() instead of nextLine() to read individual strings
        }
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (arr[i].compareTo(arr[j]) > 0) { // Corrected comparison
                    String temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
        System.out.println("The sorted array is :");
        for (int i = 0; i < n; i++) {
            System.out.println(arr[i]); // Print each element in a new line
        }
    }
}
