import java.util.Scanner;
class factorial_zoho{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        int fact=1;
        int sum=0;
        for(int i=1;i<=n;i++){
            fact=fact*i;
            sum=sum+fact;
        }
        System.out.println(sum);
    }
}