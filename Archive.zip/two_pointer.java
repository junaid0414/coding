import java.util.Scanner;
class two_pointer{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("target");
        int target=Sc.nextInt();
        int i=0;
        int j=n-1;
        while(i<j){
            int curr=arr[i]+arr[j];
            if(curr==target){
                System.out.println(i+" "+j);
                break;
            }
            if(curr<target){
                i++; 
            }
            else{
                j--;
            }
        }
    }
}