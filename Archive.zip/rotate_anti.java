// import java.util.Scanner;
// class rotate_anti{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the arrays size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements in the array: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("enter the rotations times: ");
//         int k=Sc.nextInt();
//         for(int i=0;i<k;i++){
//             int temp=arr[0];
//             for(int j=1;j<n;j++){
//                 arr[j-1]=arr[j];
//             }
//             arr[n-1]=temp;
//             System.out.print(arr[i]);
//         }
//         System.out.println();
//     }
// }


// import java.util.*;
// class rotate_anti{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the arrays size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements in the array: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("enter the rotations times: ");
//         int k=Sc.nextInt();
//         for(int i=0;i<k;i++){
//             int temp=arr[0];
//             for(int j=1;j<n;j++){
//                 arr[j-1]=arr[j];
//             }
//             arr[n-1]=temp;
//         }
//         System.out.println("sorted array is: ");
//         for(int i=0;i<n;i++){
//             System.out.println(arr[i]);
//         }
//     }
// }


// import java.util.*;
// class rotate_anti{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the arrays size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements in the array: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("enter the rotations times: ");
//         int k=Sc.nextInt();
//         for(int i=0;i<k;i++){
//             int temp=arr[0];
//             for(int j=1;j<n;j++){
//                 arr[j-1]=arr[j];
//             }
//             arr[n-1]=temp;
//         }
//         System.out.println("sorted array is: ");
//         for(int i=0;i<n;i++){
//             System.out.println(arr[i]);
//         }
//     }
// }

// import java.util.*;
// class rotate_anti{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the arrays size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements in the array: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("enter the rotations times: ");
//         int k=Sc.nextInt();
//         for(int i=0;i<k;i++){
//             int temp=arr[0];
//             for(int j=1;j<n;j++){
//                 arr[j-1]=arr[j];
//             }
//             arr[n-1]=temp;
//         }
//         System.out.println("sorted array is: ");
//         for(int i=0;i<n;i++){
//             System.out.println(arr[i]);
//         }
//     }
// }




// import java.util.Scanner;
// class rotate_anti{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }

//         for(int i=0;i<n;i++){
//             int first=arr[0];
//             for(int j=1;j<n;j++){
//                 arr[j-1]=arr[j];
//             }
//             arr[n-1]=first;
//             System.out.println(arr[i]);
//         }
//     }
// }








// import java.util.Scanner;
// class rotate_anti{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         int k=Sc.nextInt();
//         int count=0;
//         while(count!=n){
//             for(int i=0;i<n;i++){
//                 int temp=arr[0];
//                 for(int j=1;j<n;j++){
//                     arr[j-1]=arr[j];
//                 }
//                 arr[n-1]=temp;
//                 count++;
//                 System.out.println(arr[i]);
//             }
//         }
//     }
// }