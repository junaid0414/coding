// Input:
// N = 5
// Arr[] = {4, 2, 1, 5, 3}
// Output:
// 2 1 -1 3 -1
// Explanation: Array elements are 4, 2, 1, 5
// 3. Next to 4 is 2 which is smaller, so we
// print 2. Next of 2 is 1 which is smaller,
// so we print 1. Next of 1 is 5 which is
// greater, so we print -1. Next of 5 is 3
// which is smaller, so we print 3.  Note
// that for last element, output is always 
// going to be -1 because there is no element
// on right.


import java.util.Scanner;
class immediate_smaller{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the eleemnts:" );
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }

        for(int i=0;i<n-1;i++){
            if(arr[i]>arr[i+1]){
                System.out.println(arr[i+1]);
            }
            else{
                System.out.println("-1");
            }
           
        }
        System.out.println("-1");

    }
}