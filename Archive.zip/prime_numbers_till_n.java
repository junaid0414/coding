import java.util.Scanner;
public class prime_numbers_till_n {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the n value: ");
        int n=Sc.nextInt();
        if(n==0 || n==1){
            return;
        }
        int sum=0;
        for(int i=2;i<=n;i++){
            boolean isprime=true;
            for(int j=2;j<=Math.sqrt(i);j++){
                if(i%j==0){
                    isprime=false;
                }
            }
            if(isprime==true){
                System.out.println(i);
            }
        }
        // System.out.println("the sum is: ");
        // System.out.println(sum);
    }
}
