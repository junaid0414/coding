import java.util.Scanner;
class add_binary{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n1=Sc.nextLine();
        System.out.println("Enter the another string: ");
        String n2=Sc.nextLine();
        
    }
}