import java.util.Scanner;
class reverse{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the aray size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements in the array: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("the reverse of the array is: ");
        for(int i=n-1;i>=0;i--){
            System.out.print(arr[i]+" ");
        }
        System.out.println();
    }
}