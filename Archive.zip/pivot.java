import java.util.Scanner;
class pivot{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int arrsum=0;
        int formula=(n*(n+1))/2;
        for(int i=0;i<n;i++){
            arrsum=arrsum+arr[i];
            if(arrsum==formula){
                System.out.println(arr[i]);
            }
            formula=formula-arr[i];
        } 
    }
}