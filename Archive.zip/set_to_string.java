import java.util.Scanner;
import java.util.LinkedHashSet;
import java.util.Iterator;
class set_to_string{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        LinkedHashSet<Character> set=new LinkedHashSet<>();
        for(int i=0;i<n.length();i++){
            set.add(n.charAt(i));
        }
        StringBuilder sb=new StringBuilder();
        Iterator it=set.iterator();
        while(it.hasNext()){
            sb.append(it.next());
        }
        System.out.println(sb.toString());
    }
}