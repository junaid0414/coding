class problem4{
    public static void main(String arg[]){
        int marks[]={97,94,99};
        for(int i=0;i<3;i++){
            System.out.println(marks[i]);
        }
    }
}