import java.util.Scanner;
class Main{
    public static void main(String agrs[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the number: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("enter the position to search: ");
        int n1=Sc.nextInt();
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(arr[i]>arr[j]){
                    int temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                }
            }
        }
        System.out.println("the sorted array is :");
        for(int i=0;i<n;i++){
            System.out.println(arr[i]);
            
        }
        System.out.println("the sorted element is: ");
        int largest=arr[(n1-1)];
        System.out.println(largest);
        
    }
}