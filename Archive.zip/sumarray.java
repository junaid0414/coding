import java.util.Scanner;
class sumarray{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the elements in the array: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements in the array: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int sum=0;
        for(int i=0;i<n;i++){
            sum=sum+arr[i];
        }
        System.out.println("the sum of elements in the array is: "+sum);
    }
}