import java.util.Scanner;
class remove_consonants{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        String words[]=n.split(" ");

        StringBuilder sb=new StringBuilder();
        for(int i=0;i<words.length;i++){
            String check=words[i].replaceAll("[bBcCdDfFgGhHjJkKlLmMnNpPqQrRsStTwWxXyYzZ]","");
            sb.append(check);
        }
        System.out.println(sb);
    }
}