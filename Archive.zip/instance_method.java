import java.util.Scanner;
public class instance_method {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the first nu,ber: ");
        int n1=Sc.nextInt();
        System.out.println("Enter the second number: ");
        int n2=Sc.nextInt();

        instance_method in=new instance_method();
        System.out.println("smallest number: "+sum(n1,n2));
    }
    int sum(int n1,int n2){
        if(n1<n2){
            return n1;
        }
        else{
            return n2;
        }
       
    }
}
