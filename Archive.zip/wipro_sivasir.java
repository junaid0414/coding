// input={10,87,63,42,2}
// 1.) first take the max number in array
// 2.) add the whole array with the max number in array
// 3.)after adding the the whole array with max then multiply with that
// o/p: 8439,15138,13050,11223,7743




import java.util.Scanner;
class wipro_sivasir{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int []result=yes(n,arr);
        System.out.print("The result is: ");
        for (int i = 0; i < result.length; i++) {
            System.out.print(result[i] + " ");
            }    
        }

    public static int[] yes(int n,int arr[]){
        int max=arr[0];
        for(int i=1;i<n;i++){
            if(arr[i]>max){
                max=arr[i];
            }
        }

        int arr1[]=new int[n];
        for(int i=0;i<n;i++){
            arr1[i]=max+arr[i];
        }

        int arr2[]=new int[n];
        for(int i=0;i<arr1.length;i++){
            arr2[i]=arr1[i]*max;
        }
        return arr2;
    }
}







        // int arr2[]=new int[n];
        // for(int i=0;i<arr1.length;i++){
        //     arr2[i]=max*arr1[i];
        // }