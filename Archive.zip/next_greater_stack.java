import java.util.Scanner;
import java.util.Stack;
class next_greater_stack{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        Stack<Integer> stack=new Stack<>();
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int greater[]=new int[n];
        for(int i=n-1;i>=0;i--){
            while(!stack.isEmpty() && arr[i]>=stack.peek()){
                stack.pop();
            }
            if(stack.isEmpty()){
                greater[i]=-1;
            }
            else{
                greater[i]=stack.peek();
            }
            stack.push(arr[i]);
        }
        System.out.println("the current elements are: ");
        for(int i=0;i<n;i++){
            System.out.println(greater[i]);
        }
    }
}



