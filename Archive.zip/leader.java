import java.util.Scanner;
class leader{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elemeentS: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int max=arr[n-1];
        for(int i=n-2;i>=0;i--){
            if(arr[i]>max){
                max=arr[i];
                System.out.println(max);
            }
        }
        System.out.println(arr[n-1]);
    }
}