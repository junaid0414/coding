import java.util.Scanner;
class wiproq{

    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        int n=Sc.nextInt();
        String q=Integer.toString(n);
        int count=0;
        for(int i=0;i<q.length();i++){
            count++;
        }
        int temp=n;
        int k=0;
        int arr[]=new int[count];
        while(temp>0){
            int digit=temp%10;
            arr[k]=digit;
            k++;
            temp/=10;
        }
        for(int i=0;i<q.length();i++){
            System.out.println(arr[i]);
        }
        int l=count-1;
        int m=count-2;
        int sum=1;
        while(l>=1 && m>=0){
            int power=(int)Math.pow(arr[l],arr[m]);
            sum=sum+power;
            l--;
            m--;
            
        }
        System.out.println("the sum is: "+sum);
        
    }
}