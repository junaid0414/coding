// import java.util.Scanner;
// class prime_a_to_b{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the first number: ");
//         int n1=Sc.nextInt();
//         System.out.println("Enter the second number: ");
//         int n2=Sc.nextInt();
//         int i,j;
//         for(i=n1;i<=n2;i++){
//             for(j=2;j<=i;j++){
//                 if(i%j==0)
//                     break;
//             }
//             if(i==j){
//                 System.out.println("the j is: "+j);
//             }
//         }
//     }
// }



import java.util.Scanner;
class prime_a_to_b{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the first number: ");
        int n1=Sc.nextInt();
        System.out.println("Enter the second number: ");
        int n2=Sc.nextInt();
        // int i,j;
        // for(i=n1;i<=n2;i++){
        //     for(j=2;j<=i;j++){
        //         if(i%j==0)
        //             break;
        //     }
        //     if(i==j){
        //         System.out.println("the j is: "+j);
        //     }
        // }
        int i,j;
        for(i=n1;i<=n2;i++){
            boolean prime=true;
            for(j=2;j<=Math.sqrt(i);j++){
                if(i%j==0){
                    prime=false;
                    break;
                }
            }
            if(prime==false){
                System.out.println(i);
            }
        }
    }
}






























