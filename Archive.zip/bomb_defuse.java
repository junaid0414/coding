import java.util.Scanner;
class bomb_defuse{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements :");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("Enter the k value: ");
        int k=Sc.nextInt();

        int result[]=bomb(n,arr,k);
        System.out.println("the resultant array is: ");
        for(int i=0;i<n;i++){
            System.out.println(result[i]);
        }
    }

    public static int[] bomb(int n,int arr[],int k){
        int n1=arr.length;
        int ans[]=new int[n];
        if(k==0){
            return ans;
        }
        if(k>0){
            for(int i=0;i<n;i++){
                for(int j=1;j<=k;j++){
                    ans[i]=ans[i]+arr[(i+j)%n1];
                }
            }
        }
        else{
            for(int i=0;i<n;i++){
                for(int j=0;j<=-1*k;j++){
                    ans[i]=ans[i]+arr[(n-i+j)%n];
                }
            }
        }
        return ans;
    } 
}