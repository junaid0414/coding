// https://www.geeksforgeeks.org/problems/row-with-max-1s0023/1?page=1&category=Matrix&sortBy=submissions
import java.util.Scanner;
class row_with_maximum_ones{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enetr the n size: ");
        int n=Sc.nextInt();
        System.out.println("Enter the m size: ");
        int m=Sc.nextInt();
        int arr[][]=new int[n][m];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                arr[i][j]=Sc.nextInt();
            }
        }
        int result=row(n,m,arr);
        System.out.println("The result is: "+result);
    }
    public static int row(int n,int m ,int arr[][]){
        int ele=-1;
        int max=Integer.MIN_VALUE;
        for(int i=0;i<n;i++){
            int count=0;
            for(int j=0;j<m;j++){
                if(arr[i][j]==1){
                    count++;
                }
            }
            if(count>max){
                max=count;
                ele=i;
            }
        }
        return ele;
    }
}