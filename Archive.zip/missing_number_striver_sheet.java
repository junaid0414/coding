import java.util.Scanner;
class missing_number_striver_sheet{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int hash[]=new int[n+1];
        for(int i=0;i<n;i++){
            hash[arr[i]]=1;
        }

        for(int i=1;i<=n;i++){
            if(arr[i]==0){
                System.out.println(arr[i]);
                break;
            }
        }
    }
}