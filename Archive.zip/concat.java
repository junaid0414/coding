import java.util.Scanner;
class concat{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        System.out.println("Enter the second string: ");
        String m=Sc.nextLine();
        String last=n.concat(m);
        System.out.println(last);
    }
}