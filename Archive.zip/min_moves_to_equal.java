import java.util.*;
class min_moves_to_equal{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        Arrays.sort(arr);

        int i=0;
        int j=n-1;
        int ans=0;
        while(i<j){
            ans=ans+(arr[j]-arr[i]);
            i++;
            j--;
        }
        System.out.println(ans);
    }
}