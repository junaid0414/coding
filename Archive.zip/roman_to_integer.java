//check this problem in leetcode or gfg (link is below)
// https://leetcode.com/problems/roman-to-integer/description/


import java.util.Scanner;
import java.util.HashMap;
class roman_to_integer{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        HashMap<Character,Integer> map=new HashMap<>();
        int n1=n.length();
        map.put('I',1);
        map.put('V',5);
        map.put('X',10);
        map.put('L',50);
        map.put('C',100);
        map.put('D',500);
        map.put('M',1000);

        int sum=0;
        for(int i=0;i<n.length();i++){
            char ch=n.charAt(i);

            if((i+1)<n1 && map.get(ch)<map.get(n.charAt(i+1))){
                sum=sum-map.get(ch);
            }
            else{
                sum=sum+map.get(ch);
            }
        }
        System.out.println(sum);
    }
}