import java.util.Scanner;
class add_digits_till_zero{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();

        int result=hi(n);
        System.out.println(result);
    }
    public static int hi(int n){
        if(n==0){
            return 0;
        }
        else if(n%9==0){
            return 9;
        }
        else{
            return n%9;
        }
    }
}