import java.util.*;
public class max_vowels_in_substring {
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        int max=Integer.MIN_VALUE;
        String letter="";
        
        for(int i=0;i<n.length();i++){
            for(int j=i;j<n.length();j++){
                String hsh=n.substring(i,j+1);
                int vowels=countvowels(hsh);

                if(vowels>max){
                    max=vowels;
                    letter=hsh;
                }
            }
        }
        System.out.println("The max vowels is: "+max);
        System.out.println("the max vowels of substring is: "+letter);
    }
    private static int countvowels(String n){
        int count=0;
        for(int ch:n.toLowerCase().toCharArray()){
            if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' ){
                count++;
            }
        }
        return count;
    }
}


