import java.util.Scanner;
class program{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[][]=new int[n][n];
        System.out.println("Enter teh eleemtns: ");
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                arr[i][j]=Sc.nextInt();
            }
        }
        int count=0;
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                if(i%2!=0){
                    for(int k=n-1;k>=j;k--){
                        System.out.print(arr[i][k]);
                        count++;
                        if(count==n-1){
                            break;
                        }
                    }
                }
                else{
                    System.out.print(arr[i][j]);
                }
            }
            System.out.println();
        }
    }
}