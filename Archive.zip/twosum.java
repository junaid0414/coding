// Input: nums = [2,7,11,15], target = 9
// Output: [0,1]
// Explanation: Because nums[0] + nums[1] == 9, we return [0, 1]
// import java.util.Scanner;
// class twosum{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the array size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements in the array :");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("enter the target element: ");
//         int target=Sc.nextInt();
//         for(int i=0;i<n;i++){
//             for(int j=i+1;j<n;j++){
//                 if(arr[i]+arr[j]==target){
//                     System.out.println(i+" "+j);
//                 }
//             }
//         }
//     }
// }


import java.util.Scanner;
class twosum{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("Enter the target: ");
        int target=Sc.nextInt();
        int i=0,j=n-1;
        while(i<j){
            int x=arr[i]+arr[j];
            if(x==target){
                System.out.println(i+" "+j);
            }
            if(x<target){
                j--;
            }
            else{
                i++;
            }
        }
    }
}

