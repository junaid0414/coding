import java.util.*;
public class accentture {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        String ans="";
        int count=0;
        for(int i=0;i<n.length();i++){
            if(n.charAt(i)=='1'){
                count++;
            }
            else{
                if(count>0){
                    int z=64+count;
                    ans=ans+(char)z;
                    count=0;
                }
            }
        }
        if(count>0){
            int z=64+count;
            ans=ans+(char)z;
        }
        System.out.println(ans);
    }
}



