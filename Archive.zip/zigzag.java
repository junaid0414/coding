import java.util.Scanner;
class zigzag{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the sizse: ");;
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        for(int i=0;i<n-1;i=i+2){
            if(arr[i]>arr[i+1]){
                int temp=arr[i];
                arr[i]=arr[i+1];
                arr[i+1]=temp;
            }
            // else if(arr[i]<arr[i+1]){
            //     int temp1=arr[i];
            //     arr[i]=arr[i+1];
            //     arr[i+1]=temp1;
            // }
        }
        System.out.println("the array is: ");
        for(int i=0;i<n;i++){
            System.out.println(arr[i]);
        }
    }
}