// //method 1 👇👇👇👇👇👇👇
// // import java.util.Scanner;
// // import java.util.ArrayList;
// // class uncommon_elements{
// //     public static void main(String[] args) {
// //         Scanner Sc=new Scanner(System.in);
// //         System.out.println("Enetr the size: ");
// //         int n=Sc.nextInt();
// //         int arr[]=new int[n];
// //         System.out.println("Enetr the elemebnts: ");
// //         for(int i=0;i<n;i++){
// //             arr[i]=Sc.nextInt();
// //         }

// //         System.out.println("Enetr the size: ");
// //         int n1=Sc.nextInt();
// //         int arr1[]=new int[n1];
// //         System.out.println("Enetr the elemebnts: ");
// //         for(int i=0;i<n1;i++){
// //             arr1[i]=Sc.nextInt();
// //         }
// //         ArrayList<Integer> list=new ArrayList<>();
// //         int length=n+n1;
// //         int last_array[]=new int[length];

// //         for(int i=0;i<n;i++){
// //             last_array[i]=arr[i];
// //         }
// //         for(int i=0;i<n1;i++){
// //             last_array[n+i]=arr1[i];
// //         }
        
// //         for(int i=0;i<last_array.length;i++){
// //             int count=0;
// //             for(int j=0;j<last_array.length;j++){
// //                 if(i!=j && last_array[i]==last_array[j]){
// //                     count++;
// //                     break;
// //                 }
// //             }
// //             if(count==0){
// //                 list.add(last_array[i]);
// //             }
// //         }
// //         int sum=0;
// //         for(int i=0;i<list.size();i++){
// //             sum=sum+list.get(i);
// //         }
// //         if(sum==0){
// //             System.out.println("0");
// //         }
// //         else if(sum%9==0){
// //             System.out.println("9");
// //         }
// //         else{
// //             System.out.println(sum%9);
// //         }
// //     }
// // }







// //method 2 👇👇👇👇
// import java.util.Scanner;
// import java.util.HashMap;
// class uncommon_elements{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enetr the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enetr the elemebnts: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }

//         System.out.println("Enetr the size: ");
//         int n1=Sc.nextInt();
//         int arr1[]=new int[n1];
//         System.out.println("Enetr the elemebnts: ");
//         for(int i=0;i<n1;i++){
//             arr1[i]=Sc.nextInt();
//         }
//         int k=n+n1;
//         int ans[]=new int[k];
        
//         for(int i=0;i<n;i++){
//             ans[i]=arr[i];
//         }

//         for(int i=0;i<n1;i++){
//             ans[n+i]=arr1[i];
//         }

//         for(int i=0;i<k;i++){
//             System.out.println(ans[i]);
//         }

//         HashMap<Integer,Integer> map=new HashMap<>();
//         for(int i=0;i<k;i++){
//             if(map.containsKey(ans[i])){
//                 map.put(ans[i],map.get(ans[i])+1);
//             }
//             else{
//                 map.put(ans[i],1);
//             }
//         }
//         for(int key:map.keySet()){
//             if(map.get(key)==1){
//                 int x=key;
//                 if(x==0){
//                     System.out.println(0);
//                 }
//                 else if(x%9==0){
//                     System.out.println(9);
//                 }
//                 else{
//                     System.out.println(x%9);
//                 }
//             }

//         }
//     }
// }






import java.util.Scanner;
class uncommon_elements{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        
    }
}