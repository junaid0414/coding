// import java.util.Scanner;
// import java.util.ArrayList;
// class uncommon_ascii{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size :");
//         int n=Sc.nextInt();
//         char arr[]=new char[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.next().charAt(0);
//         }

//         System.out.println("Enter the another size: ");
//         int n1=Sc.nextInt();
//         char arr1[]=new char[n1];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n1;i++){
//             arr1[i]=Sc.next().charAt(0);
//         }

//         int length=n+n1;

//         char ans[]=new char[length];
//         for(int i=0;i<n;i++){
//             ans[i]=arr[i];
//         }

//         for(int i=0;i<n1;i++){
//             ans[n+i]=arr1[i];
//         }

//         ArrayList<Character> list=new ArrayList<>();
//         ArrayList<Integer> anslist=new ArrayList<>();
//         for(int i=0;i<length;i++){
//             int count=0;
//             for(int j=0;j<length;j++){
//                 if(i!=j && ans[i]==ans[j]){
//                     count++;
//                     break;
//                 }
//             }
//             if(count==0){
//                 list.add(ans[i]);
//             }
//         }
//         int x=0;
//         for(int i=0;i<list.size();i++){
//             x=(int)list.get(i);
//         }
//         if(x%9==0){
//             System.out.println(9);
//         }
//         else if(x==0){
//             System.out.println(0);
//         }
//         else{
//             System.out.println(x%9);
//         }
//     }
// }







import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;
class uncommon_ascii{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size :");
        int n=Sc.nextInt();
        char arr[]=new char[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.next().charAt(0);
        }

        System.out.println("Enter the another size: ");
        int n1=Sc.nextInt();
        char arr1[]=new char[n1];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n1;i++){
            arr1[i]=Sc.next().charAt(0);
        }

        int length=n+n1;

        char ans[]=new char[length];
        for(int i=0;i<n;i++){
            ans[i]=arr[i];
        }

        for(int i=0;i<n1;i++){
            ans[n+i]=arr1[i];
        }

        HashMap<Character,Integer> map=new HashMap<>();
        for(int i=0;i<length;i++){
            if(map.containsKey(ans[i])){
                map.put(ans[i],map.get(ans[i])+1);
            }
            else{
                map.put(ans[i],1);
            }
        }
        for(char key:map.keySet()){
            if(map.get(key)==1){
                int x=(int)key;
                if(x==0){
                    System.out.println(0);
                }
                else if(x%9==0){
                    System.out.println(9);
                }
                else{
                    System.out.println(x%9);
                }
            }
        }
    }
}