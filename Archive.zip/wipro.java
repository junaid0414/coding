// import java.util.Scanner;
// class wipro{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enetr input1");
//         int input1=Sc.nextInt();
//         System.out.println("Enetr input1");
//         int input2=Sc.nextInt();
//         System.out.println("Enetr input1");
//         int input3=Sc.nextInt();
//         System.out.println("Enetr input1");
//         int input4=Sc.nextInt();

//         int result=hi(input1,input2,input3,input4);
//         System.out.println(result);
//     }
//     public static int hi(int input1,int input2,int input3,int input4){
//         int min1=Integer.MAX_VALUE;
//         int max1=Integer.MIN_VALUE;
//         while(input1!=0){
//             int digit=input1%10;
//             if(digit<min1){
//                 min1=digit;
//             }
//             if(digit>max1){
//                 max1=digit;
//             }
//             input1/=10;
//         }
        
//         int min2=Integer.MAX_VALUE;
//         int max2=Integer.MIN_VALUE;
//         while(input2!=0){
//             int digit=input2%10;
//             if(digit<min2){
//                 min2=digit;
//             }
//             if(digit>max2){
//                 max2=digit;
//             }
//             input2/=10;
//         }
//         int min3=Integer.MAX_VALUE;
//         int max3=Integer.MIN_VALUE;
//         while(input3!=0){
//             int digit=input3%10;
//             if(digit<min3){
//                 min3=digit;
//             }
//             if(digit>max3){
//                 max3=digit;
//             }
//             input3/=10;
//         }
//         int ans=((max1*min1)+(max2*min2)+(max3*min3))-input4;
//         return ans;
//     }
// }





// // import java.util.Scanner;

// // class wipro {
// //     public static void main(String[] args) {
// //         Scanner sc = new Scanner(System.in);
// //         System.out.println("Enter input1");
// //         int input1 = sc.nextInt();
// //         System.out.println("Enter input2");
// //         int input2 = sc.nextInt();
// //         System.out.println("Enter input3");
// //         int input3 = sc.nextInt();

// //         int result = hi(input1, input2, input3);
// //         System.out.println(result);
// //     }

// //     public static int hi(int input1, int input2, int input3) {
// //         int min1 = Integer.MAX_VALUE;
// //         int max1 = Integer.MIN_VALUE;

// //         while (input1 != 0) {
// //             int digit = input1 % 10;
// //             if (digit < min1) {
// //                 min1 = digit;
// //             }
// //             if (digit > max1) {
// //                 max1 = digit;
// //             }
// //             input1 /= 10;
// //         }

// //         // You can add similar logic for input2 and input3 if required
// //         return min1; // or return any other desired result
// //     }
// // }






import java.util.*;
class wipro{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the input1: ");
        int input1=Sc.nextInt();
        System.out.println("Enter the input2: ");
        int input2=Sc.nextInt();
        System.out.println("Enter the input3: ");
        int input3=Sc.nextInt();
        System.out.println("Enter the input4: ");
        int input4=Sc.nextInt();
        int min=Integer.MAX_VALUE; //2734577544
        int max=Integer.MIN_VALUE; //-273465434

        while(input1!=0){
            int digit=input1%10;
            if(digit<min){
                min=digit;
            }
            if(digit>max){
                max=digit;
            }
            input1=input1/10;
        }

        int min1=Integer.MAX_VALUE;
        int max1=Integer.MIN_VALUE;

        while(input2!=0){
            int digit=input2%10;
            if(digit<min1){
                min1=digit;
            }
            if(digit>max1){
                max1=digit;
            }
            input2=input2/10;
        }

        int min2=Integer.MAX_VALUE;
        int max2=Integer.MIN_VALUE;
        while(input3!=0){
            int digit=input3%10;
            if(digit<min2){
                min2=digit;
            }
            if(digit>max2){
                max2=digit;
            }
            input3=input3/10;
        }

        int pin=((max*min)+(max1*min1)+(max2*min2))-input4;
        System.out.println(pin);

    }
}