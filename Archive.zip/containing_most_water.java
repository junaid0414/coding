//leetcode 11 problem
import java.util.Scanner;
class containing_most_water{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int result=water(n,arr);
        System.out.println("the maximum water is: "+result);
    }
    public static int water(int n,int arr[]){
        int max=Integer.MIN_VALUE;
        int i=0;
        int j=n-1;
        while(i<j){
            int width=j-i;
            int height=Math.min(arr[i],arr[j]);
            int pro=width*height;
            if(arr[i]<arr[j]){
                i++;
            }
            else{
                j--;
            }
            max=Math.max(pro,max);
        }
        return max;
    }
}