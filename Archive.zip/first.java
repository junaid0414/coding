import java.util.Scanner;
class first{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter teh size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter teh elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int maxsum=0;
        for(int i=0;i<n;i++){
            int sum=0;
            for(int j=i;j<n;j++){
                sum=sum+arr[i];
                if(maxsum<sum){
                    maxsum=sum;
                }
            }
        }
        System.out.println(maxsum);
    }
}