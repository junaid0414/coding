import java.util.*;
class Main{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        
        HashSet<Integer> list=new HashSet<>();
        System.out.println("Enter the number: ");
        int n1=Sc.nextInt();
        int arr1[]=new int[n1];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n1;i++){
            arr1[i]=Sc.nextInt();
        }
        
        for(int i=0;i<n;i++){
            for(int j=0;j<n1;j++){
                if(arr[i]==arr1[j]){
                    list.add(arr[i]);
                }
            }
        }
        int ans[]=new int[list.size()];
        int index=0;
        for(int key:list){
            ans[index]=key;
            index++;
        }
        System.out.println("the system is: ");
        for(int i=0;i<ans.length;i++){
            System.out.println(ans[i]);
        }
    }
}