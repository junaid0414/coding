import java.util.Scanner;
class frequency{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements in the array :");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        for(int j=0;j<n;j++){
            int count=0;
            for(int k=j;k<n;k++){
                if(arr[j]==arr[k]){
                    System.out.println("the repeated elements are: "+arr[j]);
                    count++;
                }
            }
            if(count>0){
                System.out.println("the frequency is: "+arr[j]);
            }
        }
    }
}


