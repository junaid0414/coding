import java.util.Scanner;
class prime_index_element_add{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elments: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        for(int i=0;i<n;i++){
            boolean isprime=true;
            if(i<2){
                arr[i]=0;
            }
            else{
                for(int j=2;j<=Math.sqrt(i);j++){
                    if(i%j==0){
                        isprime=false;
                    }
                }
            }
            if(isprime==false){
                arr[i]=0;
            }
        }
        System.out.println("the array is: ");
        int sum=0;
        for(int i=0;i<n;i++){
            sum=sum+arr[i];
        }
        System.out.println(sum);
    }
}