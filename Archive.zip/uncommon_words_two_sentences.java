// Input: s1 = "this apple is sweet", s2 = "this apple is sour"

// Output: ["sweet","sour"]

// Explanation:

// The word "sweet" appears only in s1, while the word "sour" appears only in s2.

// Example 2:

// Input: s1 = "apple apple", s2 = "banana"

// Output: ["banana"]


import java.util.*;
class uncommon_words_two_sentences{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n1=Sc.nextLine();
        System.out.println("Enter the second string: ");
        String n2=Sc.nextLine();

        String words1[]=n1.split(" ");
        String words2[]=n2.split(" ");
        int length1=words1.length;
        int length2=words2.length;

        String ans[]=new String[length1+length2];

        for(int i=0;i<length1;i++){
            ans[i]=words1[i];
        }

        for(int i=0;i<length2;i++){
            ans[i+length1]=words2[i];
        }

        HashMap<String,Integer> map=new HashMap<>();
        for(int i=0;i<ans.length;i++){
            if(map.containsKey(ans[i])){
                map.put(ans[i],map.get(ans[i])+1);
            }
            else{
                map.put(ans[i],1);
            }
        }

        for(String key:map.keySet()){
            if(map.get(key)==1){
                System.out.println(key);
            }
        }
    }
}