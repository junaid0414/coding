import java.util.Scanner;
class password_strong{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Password must contains \none uppercase character\none lower case character\none number \none special character");
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();

        String result=password(n);
        System.out.println("the result is: "+result);
    }

    public static String password(String n){
        int length=n.length();
        if(length<6){
            return "Password must be at least 6 characters";
            //return "Enter at least 6 characters";
        }

        int numbercount=0;
        for(int i=0;i<n.length();i++){
            if(n.charAt(i)=='0' || n.charAt(i)=='1' || n.charAt(i)=='2' || n.charAt(i)=='3' || n.charAt(i)=='4' || n.charAt(i)=='5' || n.charAt(i)=='6' || n.charAt(i)=='7' || n.charAt(i)=='8' || n.charAt(i)=='9'){
                numbercount++;
            }
        }

        if(numbercount==0){
            return "incorrect password\npassword must contain at least one number";
        }

        int Uppercasecount=0;
        for(int i=0;i<n.length();i++){
            if(n.charAt(i)>='A' && n.charAt(i)<='Z'){
                Uppercasecount++;
            }
        }
        if(Uppercasecount==0){
            return "incorrect password\nEnter a upper case letter";
        }

        int lowercasecount=0;
        for(int i=0;i<n.length();i++){
            if(n.charAt(i)>='a' && n.charAt(i)<='z'){ 
                lowercasecount++;  
            }
        }

        if(lowercasecount==0){
            return "incorrect password\nEnter a lower case letter";
        }

        int special=0;
        for(int i=0;i<n.length();i++){
            if(n.charAt(i)=='!' || n.charAt(i)=='@' || n.charAt(i)=='#' || n.charAt(i)=='$' || n.charAt(i)=='%' || n.charAt(i)=='^' || n.charAt(i)=='&' || n.charAt(i)=='*' || n.charAt(i)=='(' || n.charAt(i)==')' || n.charAt(i)=='-' || n.charAt(i)=='_' || n.charAt(i)=='+' || n.charAt(i)=='=' ){
                special++;
            }
        } 

        if(special==0){
            return "incorrect password\nEnter a special character";
        }

        return "password created sucessfully";
    }
}