import java.util.Scanner;
import java.util.ArrayList;
class sieve_of_erathosnes{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter teh number: ");
        int n=Sc.nextInt();

        boolean arr[]=new boolean[n];
        int result=countPrimes(n,arr);
        System.out.println("the result is: "+result);
    }
    public static int countPrimes(int n,boolean arr[]){
        ArrayList<Integer> list=new ArrayList<>();
        if(n<=2){
            return 0;
        }
        for(int i=2;i*i<n;i++){
            if(arr[i]==false){
                for(int j=i*i;j<n;j=j+i){
                    arr[j]=true;
                }
            }
        }
        int count=0;
        for(int i=2;i<n;i++){
            if(arr[i]==false){
                list.add(i);
                count++;

            }
        }
        System.out.println(list);
        return count;
        
    }
}


