// import java.util.Scanner;
// class remove_vowels{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the string: ");
//         String n=Sc.nextLine();
//         String ans=n.replaceAll("[aeiou]","");
//         System.out.println(ans);
//     }
// }




// import java.util.Scanner;
// class remove_vowels{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the 1string: ");
//         String n=Sc.nextLine();
//         String ans="";
//         StringBuilder sb=new StringBuilder();
//         for(int i=0;i<n.length();i++){
//             if(n.charAt(i)!='a' && n.charAt(i)!='e' && n.charAt(i)!='i' && n.charAt(i)!='o' && n.charAt(i)!='u'){
//                 sb.append(n.charAt(i));
//             }
//         }
//         System.out.println(sb.toString());
//     }
// }








import java.util.Scanner;
class remove_vowels{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        String words[]=n.split(" +");

        StringBuilder sb=new StringBuilder();
        for(String word:words){
            String check=word.replaceAll("[aeiou]","");
            sb.append(check);
        }
        System.out.println(sb);
    }
}