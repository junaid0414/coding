import java.util.HashSet;
import java.util.Scanner;
import java.util.Collections;
import java.util.Iterator;
class hash{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        HashSet<Integer> arr=new HashSet<>();
        System.out.println("enter the sie: ");
        int n=Sc.nextInt();
        System.out.println("entet th eeifbef");
        for(int i=0;i<n;i++){
            int ele=Sc.nextInt();
            arr.add(ele);
        }
        System.out.println(arr);

    }
}