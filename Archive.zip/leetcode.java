import java.util.Arrays;
import java.util.Scanner;
class leetcode{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int arr1[]=new int[n];
        System.out.println("enetr the elements in the array: ");
        for(int i=0;i<n;i++){
            arr1[i]=Sc.nextInt();
        }
        System.out.println("enter the array size: ");
        int n1=Sc.nextInt();
        int arr2[]=new int[n1];
        System.out.println("enter the elements: ");
        for(int i=0;i<n1;i++){
            arr2[i]=Sc.nextInt();
        }
        int temp1,temp2;
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(arr1[i]>arr1[j]){
                    temp1=arr1[i];
                    arr1[i]=arr1[j];
                    arr1[j]=temp1;
                }
            }
        }
        for(int i=0;i<n1;i++){
            for(int j=i+1;j<n1;j++){
                if(arr2[i]>arr2[j]){
                    temp2=arr2[i];
                    arr2[i]=arr2[j];
                    arr2[j]=temp2;
                }
            }
        }
        System.out.println("the first sorted array is: ");
        for(int i=0;i<n;i++){
            System.out.println(arr1[i]);
        }
        System.out.println("the second sorted array is :");
        for(int i=0;i<n1;i++){
            System.out.println(arr2[i]);
        }
        System.out.println("merge sort is: ");
        int temp[]=new int [n+n1];
        for(int i=0;i<n;i++){
            temp[i]=arr1[i];
        }
        for(int i=0;i<n1;i++){
            temp[i+n]=arr2[i];
        }
        System.out.println(Arrays.toString(temp));
    }
}


// import java.util.Arrays;
// import java.util.Scanner;
// class leetcode{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the array size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements in the array: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("enter the array size: ");
//         int n1=Sc.nextInt();
//         int arr1[]=new int[n1];
//         System.out.println("enter the elements in the array: ");
//         for(int i=0;i<n1;i++){
//             arr1[i]=Sc.nextInt();
//         }
//         for(int i=0;i<n;i++){
//             for(int j=i+1;j<n;j++){
//                 if(arr[i]>arr[j]){
//                     int swap=arr[i];
//                     arr[i]=arr[j];
//                     arr[j]=swap;
//                 }
//             }
//         }
//         for(int i=0;i<n;i++){
//             for(int j=i+1;j<n1;j++){
//                 if(arr1[i]>arr1[j]){
//                     int swap=arr1[i];
//                     arr1[i]=arr1[j];
//                     arr1[j]=swap;
//                 }
//             }
//         }
//         for(int i=0;i<n;i++){
//             System.out.println(arr[i]);
//         }
//         for(int i=0;i<n1;i++){
//             System.out.println(arr1[i]);
//         }
//         int temp[]=new int[n+n1];
//         for(int i=0;i<n;i++){
//             temp[i]=arr[i];
//         }
//         for(int i=0;i<n1;i++){
//             temp[i+n]=arr1[i];
//         }
//         System.out.println( "The common sorted elements are :");
//         System.out.println(Arrays.toString(temp));
//     }
// }

