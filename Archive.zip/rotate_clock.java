import java.util.Scanner;
class rotate_clock{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the arrays size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements in the array: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("enter the rotations times: ");
        int rotate=Sc.nextInt();
        for(int i=0;i<rotate;i++){
            int temp=arr[n-1];
            for(int j=n-2;j>=0;j--){
                arr[j+1]=arr[j];
            }
            arr[0]=temp;
        }
        System.out.println("sorted array is: ");
        for(int i=0;i<n;i++){
            System.out.println(arr[i]);
        }
    }
}
