import java.util.Scanner;
import java.util.TreeMap;
class hashmap_descending_order{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        TreeMap<Integer,String>map=new TreeMap<>();
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        
        
    }
}


// TreeMap<Integer, String> treeMap = new TreeMap<>();