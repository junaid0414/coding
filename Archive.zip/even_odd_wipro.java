import java.util.Scanner;
class even_odd_wipro{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the input1: ");
        int input1=Sc.nextInt();
        System.out.println("Enetr the input2: ");
        int input2=Sc.nextInt();
        System.out.println("Enter the input3: ");
        int input3=Sc.nextInt();

        int evensum=0;
        int oddsum=0;

        while(input1!=0){
            int digit=input1%10;
            if(digit%2==0){
                evensum=evensum+digit;
            }
            else{
                oddsum=oddsum+digit;
            }
            input1/=10;
        }

        while(input2!=0){
            int digit=input2%10;
            if(digit%2==0){
                evensum=evensum+digit;
            }
            else{
                oddsum=oddsum+digit;
            }
            input2/=10;
        }

        while(input3!=0){
            int digit=input3%10;
            if(digit%2==0){
                evensum=evensum+digit;
            }
            else{
                oddsum=oddsum+digit;
            }
            input3/=10;
        }

        System.out.println("the sum is: ");
        System.out.println(evensum);
        System.out.println(oddsum);
    }
}