// a1[] = {11, 7, 1, 13, 21, 3, 7, 3}
// a2[] = {11, 3, 7, 1, 7}
// Output:
// Yes
// Explanation:
// a2[] is a subset of a1[]

import java.util.Scanner;
class array_subset_of_another_array{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("enter the array size: ");
        int n1=Sc.nextInt();
        int arr1[]=new int[n1];
        System.out.println("enter the elements: ");
        for(int i=0;i<n1;i++){
            arr1[i]=Sc.nextInt();
        }
        int count=0;
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(arr[i]==arr[j]){
                    count++;
                }
            }
        }
        int count1=0;
        for(int i=0;i<n1;i++){
            for(int j=i+1;j<n1;j++){
                if(arr1[i]==arr1[j]){
                    count1++;
                }
            }
        }
        if(count>0 && count1>0){
            System.out.println("yes");
        }
        else{
            System.out.println("No");
        }
    }
}