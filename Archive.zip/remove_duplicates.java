import java.util.*;


class remove_duplicates{
    
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        HashSet<Integer> arr=new HashSet<Integer>();
        System.out.println("enter the arrays size:");
        int n=Sc.nextInt();
        System.out.println("enter teh elements: ");
        for(int i=0;i<n;i++){
            int ele=Sc.nextInt();
            arr.add(ele);
        }
        System.out.println(arr.size());

    }
}
  