// //brute force approach
// //optimise approach also there go and check

// import java.util.Scanner;
// class product_of_array_except_itself{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         int arr1[]=new int[n];

//         for(int i=0;i<n;i++){
//             int product=1;
//             for(int j=0;j<n;j++){
//                 if(i!=j){
//                     product=product*arr[j];
//                 }
//             }
//             arr1[i]=product;
//         }

//         //System.out.println("The product of the array is :");
//         for(int i=0;i<n;i++){
//             System.out.print(arr1[i]+" ");
//         }
//         System.out.println();
//     }
// }




// import java.util.*;
// class product_of_array_except_itself{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         int n=Sc.nextInt();
//         ArrayList<Integer> arr=new ArrayList<>();
//         for(int i=0;i<n;i++){
//             int ele=Sc.nextInt();
//             arr.add(ele);
//         }
//         ArrayList<Integer> ans=new ArrayList<>();
//         for(int i=0;i<n;i++){
//             int pro=1;
//             for(int j=0;j<n;j++){
//                 if(i!=j){
//                     pro=pro*arr.get(j);
//                 }
//             }
//             ans.add(pro);
//         }
//         System.out.println(ans);
//     }
// }






import java.util.*;

class product_of_array_except_itself {
    
    public static ArrayList<Integer> productExceptSelf(ArrayList<Integer> arr) {
        int n = arr.size();
        
        ArrayList<Integer> left = new ArrayList<>(Collections.nCopies(n, 1));
        ArrayList<Integer> right = new ArrayList<>(Collections.nCopies(n, 1));
        ArrayList<Integer> ans = new ArrayList<>(Collections.nCopies(n, 1));

        for (int i = 1; i < n; i++) {
            left.set(i, left.get(i - 1) * arr.get(i - 1));
        }

        for (int i = n - 2; i >= 0; i--) {
            right.set(i, right.get(i + 1) * arr.get(i + 1));
        }

        for (int i = 0; i < n; i++) {
            ans.set(i, left.get(i) * right.get(i));
        }

        return ans;
    }
    
    public static void main(String args[]) {
        Scanner Sc = new Scanner(System.in);
        int n = Sc.nextInt();
        
        ArrayList<Integer> arr = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            arr.add(Sc.nextInt());
        }
        
        ArrayList<Integer> result = productExceptSelf(arr);
        
        // Print the result
        System.out.println(result);
    }
}
