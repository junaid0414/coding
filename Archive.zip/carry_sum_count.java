import java.util.Scanner;
class carry_sum_count{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        int n1=11;        
        int n2=1;

        int count=0;
        while(n1>0 && n2>0){
            int digit1=n1%10;
            int digit2=n2%10;

            int sum=digit1+digit2;

            if(sum>9){
                count++;
            }
            n1/=10;
            n2/=10;
        }
        System.out.println("the result is: ");
        System.out.println(count);
    }
}




