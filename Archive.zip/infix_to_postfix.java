import java.util.Scanner;
import java.util.Stack;
class infix_to_postfix{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the infix expression");
        String n=Sc.nextLine();

        n=n.replace(" ","");
        Stack<Integer> stack=new Stack<>();
        for(int i=0;i<n.length();i++){
            char ch=n.charAt(i);

            if(Character.isDigit(ch)){
                stack.push(ch-'0');
            }
            else{
                int a=stack.pop();
                int b=stack.pop();

                switch (ch) {
                    case '+':
                        stack.push(a+b);
                        break;

                    case '-':
                    stack.push(b-a);
                    break;

                    case '*':
                    stack.push(a*b);
                    break;
                }
            }
        }
        System.out.println("the op is: "+stack.peek());
    }
}