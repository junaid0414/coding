class wordcount{
    public static void main(String[] args) {
        int arr[]={15,16,1,-2,-13,61,11,4,3,19,-4,17,-3,90,-65,67,12,0,13,2,3,43,21,-17,2,42};
        String s="SPRING";
        int sum=0;
        for(int i=0;i<s.length()-1;i++){
            char q=s.charAt(s.length()-1);
            int ascii=(int)q;
            int position=ascii-65;
            int value=arr[position];
            if(value<0){
                sum=sum+arr[position]+position;
            }
            else{
                sum=sum+value;
            }
        }
        for(int i=0;i<s.length()-2;i++){
            int ascii=(int)s.charAt(i);
            int position=ascii-65;
            int value=arr[position];
            sum=sum+value;
        }
        System.out.println(sum);
    }
}



// import java.util.Scanner;
// class wordcount{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enther the string: ");
//         String n=Sc.nextLine();
//         String mine=n.toLowerCase();
//         String arr[]=mine.split(" ");
//         for(int i=0;i<arr.length;i++){
//             int ch=(int)arr.charAt(i);
//         }
        
//     }
// }