import java.util.Scanner;
import java.util.ArrayList;
class twosumii{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        ArrayList<Integer> arr=new ArrayList<Integer>();
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            int element=Sc.nextInt();
            arr.add(element);
        }
        System.out.println("enter the target element: ");
        int target=Sc.nextInt();
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(arr.get(i)+arr.get(j)==target){
                    System.out.println(i+1);
                    System.out.println(j+1);
                }
            }
        }
    }
}


