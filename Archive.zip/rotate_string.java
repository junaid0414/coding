import java.util.Scanner;
import java.util.Arrays;
class rotate_string{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the first string: ");
        String n1=Sc.nextLine();
        System.out.println("another string: ");
        String n2=Sc.nextLine();

        boolean found=false;
        char arr1[]=n1.toCharArray();
        char arr2[]=n2.toCharArray();
        int length=n1.length();
        for(int i=0;i<length;i++){
            char temp=arr1[0];
            for(int j=1;j<length;j++){
                arr1[j-1]=arr1[j];
            }
            arr1[length-1]=temp;
            if(Arrays.equals(arr1,arr2)){
                found=true;
                break;
            }    
        }
        System.out.println(found);
    }
}
