import java.util.Scanner;
class minscalar{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int arr1[]=new int[n];
        System.out.println("enter the elements in the array: ");
        for(int i=0;i<n;i++){
            arr1[i]=Sc.nextInt();
        }
        System.out.println("enter the array size: ");
        int n1=Sc.nextInt();
        int arr2[]=new int[n1];
        System.out.println("enter the elements in the array: ");
        for(int i=0;i<n1;i++){
            arr2[i]=Sc.nextInt();
        }
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(arr1[i]>arr1[j]){
                    int temp=arr1[i];
                    arr1[i]=arr1[j];
                    arr1[j]=temp;
                }
            }
        }
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n1;j++){
                if(arr2[i]<arr2[j]){
                    int temp1=arr2[i];
                    arr2[i]=arr2[j];
                    arr2[j]=temp1;
                }
            }
        }
        int sum=0;
        for(int i=0;i<n;i++){
            sum=sum+arr1[i]*arr2[i];
        }
        System.out.println("the output is: "+sum);
    }
}