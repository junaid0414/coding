import java.util.Scanner;
class Main{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the number: ");
        int n=Sc.nextInt();
        
        int result=nums(n);
        System.out.println("the result is: "+result);
    }
    public static int nums(int n){
    int a=0,b=1,sum=0;
    for(int i=1;i<n;i++){
        int c=a+b;
        a=b;
        b=c;
        sum=sum+a;
    }
    return sum;
    }
}

