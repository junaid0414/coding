import java.util.Scanner;
class print_all_substrings{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        if(n.length()==1){
            System.out.println(n);
        }
        StringBuilder sb=new StringBuilder();
        int max=Integer.MIN_VALUE;
        String ans="";
        for(int i=0;i<n.length();i++){
            for(int j=i+1;j<n.length();j++){
                String a=n.substring(i,j+1);
                int length=a.length();
                sb.append(a);
                sb.reverse();
                if((sb.toString().equals(a)) && length>max){
                    max=length;
                    ans=a;
                }
                sb.setLength(0);
            }
        }
        System.out.println(ans);
    }
}