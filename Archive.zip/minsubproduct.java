import java.util.Scanner;
class minsubproduct{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int[] arr=new int[n];
        System.out.println("enetr teh elements : ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int productmin=0;
        for(int i=0;i<n;i++){
            int product=1;
            for(int j=i+1;j<n;j++){
                product=product*arr[j];
                if(product<productmin){
                    productmin=product;
                }
            }
        }
        System.out.println(productmin);
    }
}