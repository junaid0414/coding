import java.util.Scanner;
class wipro_oddelements{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }

        int result=yes(n,arr);
        System.out.println("The result is: "+result);
    }
    public static int yes(int n,int arr[]){
        int count=0;
        int maxcount=Integer.MIN_VALUE;
        int element=-1;
        int sum=0;
        int maxsum=0;

        for(int i=0;i<n;i++){
            if(arr[i]%2!=0){
                count++;
                if(count>maxcount){maxcount=count;
                    sum=sum+arr[i];
                    if(sum>maxsum){
                        maxsum=sum;
                    }
                }
            }
            else{
                sum=0;
            }
        }
        return maxcount;
    }
}