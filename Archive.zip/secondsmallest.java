import java.util.*;
import java.util.Collections;
class secondsmallest{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elemnts: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }

        HashSet<Integer> set=new HashSet<>();
        for(int i=0;i<n;i++){
            set.add(arr[i]);
        }

        ArrayList<Integer> list=new ArrayList<>(set);
        int count=0;
        for(int key:list){
            count++;
            if(count==2){
                System.out.println(key);
                return;
            }
        }
    }
}