// Input: digits = [1,2,3]
// Output: [1,2,4]
// Explanation: The array represents the integer 123.
// Incrementing by one gives 123 + 1 = 124.
// Thus, the result should be [1,2,4].

import java.util.Scanner;
class plus_one{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        arr[n-1]++;
        System.out.println("the sorted array is: ");
        for(int i=0;i<n;i++){
            System.out.println(arr[i]);
        }
    }
}