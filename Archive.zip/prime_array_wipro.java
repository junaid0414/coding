import java.util.ArrayList;
import java.util.Scanner;
import java.util.Collections;
class prime_array_wipro{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        ArrayList<Integer> list=new ArrayList<>();
        for(int i=0;i<n;i++){
            if(arr[i]>1){
                boolean isprime=true;
                for(int j=2;j<=Math.sqrt(arr[i]);j++){
                    if(arr[i]%j==0){
                        isprime=false;
                        break;
                    }
                }
                if(isprime==true){
                    list.add(arr[i]);
                }
                else{
                    list.add(arr[i]);
                }
            }
        }
        Collections.sort(list);
        int sum=0;
        for(int i=1;i<list.size();i++){
            sum=sum+list.get(i);
        }
        System.out.println(sum);
    }
}






























// import java.util.Scanner;
// import java.util.ArrayList;
// import java.util.Collections;
// class prinme_array_wipro{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elemens: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         ArrayList<Integer> list=new ArrayList<>();
//         for(int i=0;i<n;i++){
//             if(arr[i]>1){
//                 boolean isPrime=true;
//                 for(int j=2;j<=Math.sqrt(arr[i]);j++){
//                     if(arr[i]%i==0){
//                         isPrime=false;
//                         break;
//                     }
//                 }
//                 if(isPrime){
//                     list.add(arr[i]);
//                 }
//             }
//         }
//         Collections.sort(list);
//         int sum=0;
//         for(int i=0;i<list.size();i++){
//             sum=sum+list.get(i);
//         }
//         System.out.println(list);
//         System.out.println(sum);
//     }
// }