class problem1{
    public static void main(String arg[]){
        int[] marks=new int[3];
        marks[0]=98;
        marks[1]=99;
        marks[2]=92;
        System.out.println(marks[0]);
        System.out.println(marks[1]);
        System.out.println(marks[2]);
        
    }
}