//leetcode 371 go to neetcode for explanitaion
import java.math.BigInteger;
import java.util.Scanner;
class bit_manuplation{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the a value: ");
        String n1=Sc.nextLine();
        BigInteger a=new BigInteger(n1);//
        System.out.println("Enter the b value: ");
        String n2=Sc.nextLine();
        BigInteger b=new BigInteger(n2);

        while (!b.equals(BigInteger.ZERO)) {
            BigInteger temp = a.and(b).shiftLeft(1);
            a = a.xor(b);
            b = temp;
        }
        System.out.println(a);
    }
}