import java.util.Scanner;
class terinary{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        int a=10;
        int b=20;
        String j=(a>b)? "a is bigger" : (a==b)?"equal" :"b is bigger" ;
        System.out.println(j);
    }
}