import java.util.Scanner;
class inversion_of_array{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements in the array: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int count=0;
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(i<j){
                    if(arr[i]>arr[j]){
                        count++;
                    }
                }
            }
        System.out.println("the pairs are: ");
        if(count>1){
            System.out.println(count);
        }
    }
}
}