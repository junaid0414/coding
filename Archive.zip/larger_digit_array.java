import java.util.Scanner;
class larger_digit_array {
    public static void main(String[] args) {
        Scanner Sc = new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n = Sc.nextInt();
        int arr[] = new int[n];
        System.out.println("Enter the elements: ");
        for (int i = 0; i < n; i++) {
            arr[i] = Sc.nextInt();
        }
        int max = Integer.MIN_VALUE;
        int sum = 0;
        int min= Integer.MAX_VALUE;
        int sum1=0;
        for (int i = 0; i < n; i++) {
            while (arr[i] != 0) {
                int digit = arr[i] % 10;
                if (digit > max) {
                    max = digit;
                }
                if(digit<min){
                    min=digit;
                }
                arr[i] = arr[i] / 10;
            }
            sum=sum+max;
            sum1=sum1+min;
        }
        System.out.println(sum+"is the");
        System.out.println(sum1+"sum1 is");
    }
}