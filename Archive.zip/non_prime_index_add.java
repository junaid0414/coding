import java.util.Scanner;
public class non_prime_index_add {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int sum=0;
        for(int i=0;i<n;i++){
            boolean isprime=true;
            if(i<2){
                isprime=false;
            }
            else{
                for(int j=2;j<=Math.sqrt(i);j++){
                    if(i%j==0){
                        isprime=false;
                        break;
                    }
                }
            }
            if(isprime==false){
                sum=sum+i;
            }
        }
        System.out.println("the sum of non prime index is: ");
        System.out.println(sum);
    }
}
