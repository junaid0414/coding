import java.util.Scanner;
class nth_fibonacii{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the n value: ");
        int n=Sc.nextInt();
        int a=0;
        int b=1;
        System.out.println(a);
        System.out.println(b);
        printnum(a,b,n-2);
    }

    public static void printnum(int a,int b,int n){
        if(n==0){
            return;
        }
        int c=a+b;
        System.out.println(c);
        printnum(a=b,b=c,n-1);
    }
}