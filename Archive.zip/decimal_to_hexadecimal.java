import java.util.Scanner;
class decimal_to_hexadecimal{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        
        String hexnumber=Integer.toHexString(n);
        System.out.println(hexnumber);
    }
}




