// import java.util.Scanner;
// public class non_prime_index {
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the number: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         for(int i=2;i<n;i++){
//             boolean isprime=true;
//             for(int j=2;j<=Math.sqrt(i);j++){
//                 if(i%j==0){
//                     isprime=false;
//                     break;
//                 }
//             }
//             if(isprime==true){
//                 arr[i]=0;
//             }
//         }
//         System.out.println("the array is: ");
//         for(int i=0;i<n;i++){
//             System.out.println(arr[i]);
//         }
//     }
// }






// import java.util.Scanner;
// class non_prime_index{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the number: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         for(int i=2;i<n;i++){
//             boolean isprime=true;
//             for(int j=2;j<=Math.sqrt(i);j++){
//                 if(i%j==0){
//                     isprime=false;
//                     break;
//                 }
//             }
//             if(isprime=true){
//                 arr[i]=0;
//             }
//         }
//         for(int i=0;i<n;i++){
//             System.out.println(arr[i]);
//         }
//     }
// }







import java.util.Scanner;
class non_prime_index{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        for(int i=2;i<n;i++){
            boolean isprime=true;
            for(int j=2;j<=Math.sqrt(i);j++){
                if(i%j==0){
                    isprime=false;
                    break;
                }
            }
            if(isprime==true){
                arr[i]=0;
            }
        }
        System.out.println("the number: ");
        for(int i=0;i<n;i++){
            System.out.println(arr[i]);
        }
    }
}