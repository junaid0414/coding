import java.util.*;
public class check_two_hashmaps {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enetr the string: ");
        String n1=Sc.nextLine();
        System.out.println("Enetr the second string: ");
        String n2=Sc.nextLine();

        boolean result=ans(n1,n2);
        System.out.println("teh result is: "+result);
    }

    public static boolean ans(String n1,String n2){
        char arr1[]=n1.toCharArray();
        char arr2[]=n2.toCharArray();
        HashMap<Character,Integer> map1=new HashMap<>();
        HashMap<Character,Integer> map2=new HashMap<>();
        for(int i=0;i<arr1.length;i++){
            map1.put(arr1[i],map1.getOrDefault(arr1[i],0)+1);
        }
        for(int i=0;i<arr2.length;i++){
            map2.put(arr2[i],map2.getOrDefault(arr2[i],0)+1);
        }

        for(Map.Entry<Character,Integer> entry:map1.entrySet()){
            char key=entry.getKey();
            int value=entry.getValue();

            if(map2.containsKey(key) && map2.get(key).equals(value)){
                return true;
            }
        }
        return false;
    }
}
