import java.util.Scanner;
class problem6{
    public static void main(String arg[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the number of array blocks: ");
        int n=Sc.nextInt();
        System.out.println("enter the number of elements :");
        int number[]=new int[n];

        for(int i=0;i<n;i++){
            number[i]=Sc.nextInt();
        }
        
        System.out.println("enter the value: ");
        int x=Sc.nextInt();
        
        for(int j=0;j<number.length;j++){
            if(number[j]==x){
                System.out.println(number[j]+" found at the index value: "+j);
            }
        }
        Sc.close();
    }
}