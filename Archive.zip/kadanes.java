import java.util.Scanner;
class kadanes{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int result=kadane(n,arr);
        System.out.println("the result is: "+result);
    }
    public static int kadane(int n, int arr[]){
        int max=arr[0];
        int sum=arr[0];

        for(int i=1;i<n;i++){
            if(sum>=0){
                sum=sum+arr[i];
            }
            else{
                sum=arr[i];
            }
            if(sum>max){
                max=sum;
            }
        }
        return max;
    }q
}