import java.util.Scanner;
public class accenture_overs_problem {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the overs: ");
        int overs=Sc.nextInt();
        System.out.println("Enter the runs: ");
        int runs=Sc.nextInt();
        float complete=overs*runs;
        System.out.printf("the total runs are: %.2f\n", complete);
    }
}
