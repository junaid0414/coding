import java.util.Scanner;
class set_matrices_zero{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enetr the size: ");
        int n=Sc.nextInt();
        System.out.println("Enter the size2: ");
        int n1=Sc.nextInt();
        int arr[][]=new int[n][n1];
        int arr1[][]=new int[n][n1];
        for(int i=0;i<n;i++){
            for(int j=0;j<n1;j++){
                arr[i][j]=Sc.nextInt();
            }
        }
        for(int i=0;i<n;i++){
            for(int j=0;j<n1;j++){
                arr1[i][j]=arr[i][j];
            }
        }
        for(int i=0;i<n;i++){
            for(int j=0;j<n1;j++){
                if(arr1[i][j]==0){
                    for(int k=0;k<n;k++){
                        arr[k][j]=0;
                    }
                    for(int k=0;k<n1;k++){
                        arr[i][k]=0;
                    }
                }
            }
        }
        for(int i=0;i<n;i++){
            for(int j=0;j<n1;j++){
                System.out.print(arr[i][j]+ " ");
            }
            System.out.println();
        }
    }
}




