// arr1[] = {2, 3, 6, 7, 9}
// arr2[] = {1, 4, 8, 10}
// k = 5
// Output:
// 6
// Explanation:
// The final sorted array would be -
// 1, 2, 3, 4, 6, 7, 8, 9, 10
// The 5th element of this array is 6.


import java.util.Scanner;
class merge_sortedarray{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the element: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("enter the array size: ");
        int n1=Sc.nextInt();
        int arr1[]=new int[n1];
        System.out.println("enter the element: ");
        for(int i=0;i<n1;i++){
            arr1[i]=Sc.nextInt();
        }
        int l=n+n1;
        int temp[]=new int[l];
        for(int i=0;i<n;i++){
            temp[i]=arr[i];
        }
        for(int i=0;i<n1;i++){
            temp[n+i]=arr1[i];
        }
        for(int i=0;i<l;i++){
            for(int j=i+1;j<l;j++){
                if(temp[i]>temp[j]){
                    int swap=temp[i];
                    temp[i]=temp[j];
                    temp[j]=swap;
                }
            }
        }
        System.out.println("enter the k value: ");
        int k=Sc.nextInt();
        System.out.println("the sorted array is: ");
        for(int i=0;i<l;i++){
            System.out.println(temp[i]);
        }
        System.out.println("the k element is: ");
        for(int i=0;i<l;i++){
            System.out.println(temp[k-1]);
            break;
        }
    }
}