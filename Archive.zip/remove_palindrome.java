// import java.util.Scanner;
// class remove_palindrome{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the string: ");
//         String n=Sc.nextLine();
//         String q=n.toLowerCase();

//         String words[]=q.split(" +");
//         StringBuilder sb=new StringBuilder();
//         for(int i=0;i<words.length;i++){
//             StringBuilder sb1=new StringBuilder(words[i]);
//             sb1.reverse();
//             if(!sb1.toString().equals(words[i])){
//                 sb.append(words[i]);
//                 sb.append(" ");
//             }
//         }
//         System.out.println(sb.toString());
//     }
// }




import java.util.Scanner;
class remove_palindrome{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        String words[]=n.split(" ");
        
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<words.length;i++){
            StringBuilder sb1=new StringBuilder(words[i]);
            sb1.reverse();
            if(!sb1.toString().equals(words[i])){
                sb.append(words[i]);
                sb.append(" ");
            }
        }
        System.out.println(sb.toString());
    }
}