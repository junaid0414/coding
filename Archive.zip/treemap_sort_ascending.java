// // https:leetcode.com/problems/sort-the-people/description/?envType=daily-question&envId=2024-07-22
// import java.util.*;
// class treemap_sort_ascending{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size :");
//         int n=Sc.nextInt();
//         String arr[]=new String[n];
//         Sc.nextLine();
//         System.out.println("Enter the names: ");
//         for(int i=0;i<n;i++){

//             arr[i]=Sc.nextLine();
//         }

//         int arr1[]=new int[n];
//         System.out.println("Enter the integers: ");
//         for(int i=0;i<n;i++){
//             arr1[i]=Sc.nextInt();
//         }

//         TreeMap<Integer,String> map=new TreeMap<>(Collections.reverseOrder());
//         for(int i=0;i<n;i++){
//             map.put(arr1[i],arr[i]);
//         }
//         System.out.println(map);
//     }
// }






