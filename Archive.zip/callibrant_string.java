// i/p: "A man in the boat says i see 1 2 3 in the sky"
// o/p: "y kse ht nie esis yast a obe 1 2 3 ht nin amA"
// import java.util.Scanner;
// class callibrant_string{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the string: ");
//         String n=Sc.nextLine();

//         char arr[]=n.toCharArray();

//         StringBuilder sb=new StringBuilder();
//         for(char key:arr){
//             if(Character.isLetter(key)){
//                 sb.append(key);
//             }
//         }

//         int index=0;
//         sb.reverse();
//         for(int i=0;i<arr.length;i++){
//             if(Character.isLetter(arr[i])){
//                 arr[i]=sb.charAt(index);
//                 index++;
//             }
//         }
//         for(int i=0;i<arr.length;i++){
//             System.out.print(arr[i]);
//         }
//     }
// }



// import java.util.Scanner;
// class callibrant_string{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the String: ");
//         String n=Sc.nextLine();

//         char arr[]=n.toCharArray();

//         StringBuilder sb=new StringBuilder();

//         for(char key:arr){
//             if(Character.isLetter(key)){
//                 sb.append(key);
//             }
//         }

//         sb.reverse();

//         int index=0;
//         for(int i=0;i<arr.length;i++){
//             if(Character.isLetter(arr[i])){
//                 arr[i]=sb.charAt(index);
//                 index++;
//             }
//         }
//         System.out.println("the result is: ");
//         for(int i=0;i<arr.length;i++){
//             System.out.println(arr[i]);
//         }
//     }
// }




import java.util.Scanner;
class callibrant_string{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        StringBuilder sb=new StringBuilder();
        char arr[]=n.toCharArray();

        for(char key:arr){
            if(Character.isLetter(key)){
                sb.append(key);
            }
        }
        sb.reverse();

        String z=sb.toString();
        int index=0;
        for(int i=0;i<arr.length;i++){
            if(Character.isLetter(arr[i])){
                arr[i]=z.charAt(index);
                index++;
            }
        }
        for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]);
        }
    }
}