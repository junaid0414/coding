#include <iostream>
using namespace std;
int main(){
    int n,arr[50],k;
    cout<<"Enter the siz: ";             //i
    cin>>n;                             //{1 , 3, 2, 4, 5, 6}
    cout<<"enter teh elements:  ";       //j
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    cout<<"enter the k value: ";
    cin>>k;
    for(int i=0;i<n;i++){
        for(int j=i;j<n;j++){
            if(arr[i]+arr[j]==k){
                cout<<"the pair is: "<<i<<" "<<j<<endl;
            }
        }
    }
}