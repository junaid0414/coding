import java.util.Scanner;
class ascii_values{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the character");
        char n=Sc.next().charAt(0);
        int q=n;
        System.out.println(q);
    }
}
