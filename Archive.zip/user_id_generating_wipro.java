import java.util.Scanner;
class user_id_generating_wipro{
    public static void main(String[] args) {
        Scanner Sc = new Scanner(System.in);
        System.out.println("Enter the first name: ");
        String input1 = Sc.nextLine();
        System.out.println("Enter the second name: ");
        String input2 = Sc.nextLine();
        System.out.println("Enter the number: ");
        int input3 = Sc.nextInt();
        System.out.println("Enter the n: ");
        int input4 = Sc.nextInt();

        String result = userIdGeneration(input1, input2, input3, input4);
        System.out.println("The result is: " + result);
    }
    public static String userIdGeneration(String input1, String input2, int input3, int input4) {
        int length1 = input1.length();
        int length2 = input2.length();
        String smaller="";
        String bigger="";
        
        if(length1>length2){
            smaller=input2;
            bigger=input1;
        }
        else if(length1<length2){
            smaller=input1;
            bigger=input2;
        }
        
        return "3";
    }
}





