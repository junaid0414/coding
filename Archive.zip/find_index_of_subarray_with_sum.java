// N = 5, S = 12
// A[] = {1,2,3,7,5}
// Output: 2 4
// Explanation: The sum of elements 
// from 2nd position to 4th position 
// is 12.

import java.util.Scanner;
class find_index_of_subarray_with_sum{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the arrays size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elments: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("enter the k value: ");
        int k=Sc.nextInt();
        int result[]=window(arr,n,k);
        if(result!=null){
            System.out.println("subarray with "+result[0]+" and "+result[1]);
        }
        else{
            System.out.println("not equal");
        }
    }
    public static int[] window(int arr[],int n,int k){
        int result[]=new int[2];
        for(int i=0;i<n;i++){
            int sum=0;
            for(int j=i;j<n;j++){
                sum=sum+arr[j];
                if(sum==k){
                    result[0]=i;
                    result[1]=j;
                    return result;
                }
            }
        }
        return null;
    }
}


