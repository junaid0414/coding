import java.util.Scanner;
class unique {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the array size:");
        int n = sc.nextInt(); 
        int arr[] = new int[n];
        System.out.println("Enter the elements in the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        int ans=0;
        for(int key:arr){
            ans=ans^key;
        }
        System.out.println(ans);
    }
}