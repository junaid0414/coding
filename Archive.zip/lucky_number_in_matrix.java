// import java.util.Scanner;
// import java.util.ArrayList;
// class lucky_number_in_matrix{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enetr the rows: ");
//         int n=Sc.nextInt();
//         System.out.println("Enter the columns: ");
//         int m=Sc.nextInt();
//         int arr[][]=new int[n][m];
//         for(int i=0;i<n;i++){
//             for(int j=0;j<m;j++){
//                 arr[i][j]=Sc.nextInt();
//             }
//         }
//         ArrayList<Integer> list=new ArrayList<>();
//         for(int i=0;i<n;i++){
//             int min=Integer.MAX_VALUE;
//             for(int j=0;j<m;j++){
//                 if(arr[i][j]<min){
//                     min=arr[i][j];
//                     list.add(min);
//                 }
//             }
//         }
        
//         int temp[][]=new int[n][m];
//         for(int i=0;i<n;i++){
//             for(int j=0;j<m;j++){
//                 temp[i][j]=arr[i][j];
//             }
//         }
//         int l=temp.length;
//         int p=temp[0].length;

//         for(int i=0;i<l;i++){
//             for(int j=0;j<p;j++){
//                 System.out.print(temp[j][i]+" ");
//             }
//         }
//         ArrayList<Integer> list1=new ArrayList<>();
//         for(int i=0;i<p;i++){
//             int max=Integer.MIN_VALUE;
//             for(int j=0;j<l;j++){
//                 if(temp[l][p]>max){
//                     max=temp[l][p];
//                     list1.add(max);
//                 }
//             }
//         }
//         System.out.println("the answer is: ");
//         System.out.println(list);
//         System.out.println(list1);
//     }
// }





import java.util.Scanner;
class Main{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        System.out.println("Enter the another size: ");
        int m=Sc.nextInt();
        
        int arr[][]=new int[n][m];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                arr[i][j]=Sc.nextInt();
            }
        }
        for(int i=0;i<n;i++){
            int max=Integer.MIN_VALUE;
            for(int j=0;j<m;j++){
                if(arr[j][i]>max){
                    max=arr[j][i];
                }
            }
            System.out.println(max);
        }
    }
}