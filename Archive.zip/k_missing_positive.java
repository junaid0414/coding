// import java.util.Scanner;
// import java.util.ArrayList;
// import java.util.Collections;
// class k_missing_positive{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("Enter the k value: ");
//         int k=Sc.nextInt();
//         int result=findKthPositive(n,arr,k);
//         System.out.println(result);
//     }
//     public static int findKthPositive(int n,int arr[],int k){
//         int count=1;
//         int found=0;
//         ArrayList<Integer> list=new ArrayList<>();
//         for(int i=0;i<n;i++){
//             if(i==arr[i]){
//                 found++;
//             }
//             else{
//                 list.add(i);
//             }
//         }
//         Collections.sort(list);
//         for(int i=1;i<list.size();i++){
//             count++;
//             if(count==k){
//                 return list.get(i);
//             }
//         }
//         return -1;
//     }
// }









import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
class k_missing_positive{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("Enter the k value: ");
        int k=Sc.nextInt();
        int result=findKthPositive(n,arr,k);
        System.out.println(result);
    }
    public static int findKthPositive(int n,int arr[],int k){
        int count=k;
        for(int i=0;i<n;i++){
            if(arr[i]<count){
                count++;
            }
            else{
                return count;
            }
        }
        return -1;
    }
}