import java.util.Scanner;
class longest_palindrome_substring{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        StringBuilder sb=new StringBuilder();
        int maxl=Integer.MIN_VALUE;
        String ans="";
        for(int i=0;i<n.length();i++){
            for(int j=i+1;j<n.length();j++){
                String s=n.substring(i,j+1);
                sb.append(s);
                sb.reverse();
                if(sb.toString().equals(s)){
                    
                }
            }
        }
    }
}