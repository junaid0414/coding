//r=5,c=3 
//op:6

import java.util.Scanner;
class pascal_triangle_i{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the row: ");
        int n=Sc.nextInt();
        System.out.println("Enter the column: ");
        int r=Sc.nextInt();

        int factn=1;
        for(int i=1;i<=n-1;i++){
            factn=factn*i;
        }
        
        int factr=1;
        for(int i=1;i<=r-1;i++){
            factr=factr*i;
        }
        
        int last=n-r;
        int lastone=1;
        for(int i=1;i<=last;i++){
            lastone=lastone*i;
        }


        int ans=factn/(factr*lastone);
        System.out.println(ans);
    }
}




