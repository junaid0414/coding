import java.util.Scanner;
class product_pair{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("target element: ");
        int target=Sc.nextInt();
        int j=n-1;
        for(int i=0;i<n;i++){
            int c=arr[i]*arr[j];
            if(c==target){
                System.out.println("Yes");
                break;
            }
            else if(c>target){
                j--;
            }
            else{
                i++;
            }
        }
    }
}