import java.util.Scanner;
import java.util.Arrays;
class longest_common_prefix{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        int n=3;
        String arr[]={"flower","flow","flight"};

        Arrays.sort(arr);
        String first=arr[0];
        String last=arr[arr.length-1];
        int i=0;
        int j=0;
        StringBuilder sb=new StringBuilder();
        while(i<first.length() && j<last.length()){
            if(first.charAt(i)==last.charAt(j)){
                sb.append(first.charAt(i));
                i++;
                j++;
            }
            else{
                break;
            }
        }
        System.out.println(sb.toString());
    }
}