//0(n3) time complexity
import java.util.Scanner;
class product_of_subarray_big_0_n_three{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int result=product(n,arr);
        System.out.println("The result is: "+result);
    }
    public static int product(int n,int arr[]){
        int max=0;
        for(int i=0;i<n;i++){
            for(int j=i;j<n;j++){
                int pro=1;
                for(int k=i;k<=j;k++){
                    pro=pro*arr[k];
                }
                if(pro>max){
                    max=pro;
                }
            }
        }
        return max;
    }
}