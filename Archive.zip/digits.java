class digits{
    public static void main(String[] args) {
        int a=12345;

        int n1=(a/100)%10;
        int n2=(a/1000)%10;
        System.out.println(n1 + "  "+n2);
    }
}