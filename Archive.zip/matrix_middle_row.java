// import java.util.Scanner;
// class matrix_middle_row{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the first size: ");
//         int n=Sc.nextInt();
//         System.out.println("Enetr the second size: ");
//         int n1=Sc.nextInt();
//         int arr[][]=new int[n][n1];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             for(int j=0;j<n1;j++){
//                 arr[i][j]=Sc.nextInt();
//             }
//         }
//         System.out.println("Enter the seocnd array elements: ");
//         int arr1[][]=new int[n][n1];
//         for(int i=0;i<n;i++){
//             for(int j=0;j<n1;j++){
//                 arr1[i][j]=Sc.nextInt();
//             }
//         }
//         for(int i=0;i<n;){
//             for(int j=0;j<n1;j++){
//                 System.out.println(arr[j][1]);
//             }
//             break;
//         }
//         for(int i=0;i<n;){
//             for(int j=0;j<n1;j++){
//                 System.out.println(arr1[j][1]);
//             }
//             break;
//         }
//     }
// }










import java.util.Scanner;
class matrix_middle_row{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine();
        int count=0;
        for(int i=0;i<n.length();i++){
            if(n.charAt(i)=='-'){
                count++;
            }
        }
        String renew=n.replaceAll("[-]","");
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<=count;i++){
            sb.append("-");
        }
        sb.append(renew);
        System.out.println(sb.toString());
    }
}