// i/p:10,20,15,5,8,30,25 //arr[i]<arr[j] then arr[i]-arr[j]
// o/p: 8, 15,8,-1,-1,25,-1

import java.util.Scanner;
class next_closer_element{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=7;
        int a[]={10,20,15,5,8,30,25};
        for(int i=0;i<n;i++)
        {
            int flag=0,small=0;
            for(int j=i+1;j<n;j++)
            {
                if(a[j]<a[i])
                {
                 if(flag==0 ){
                 small=a[j];
                 flag=1;
                  }
                else if(a[j]>small)
                 small=a[j];
                }
            }
            if(flag==0)
              System.out.println(-1);
            else
              System.out.println(small);
        }
        }
    }
