import java.util.Scanner;
class nonrepeating{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements in the arrry: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        for(int i=0;i<n;i++){
            int count=1;
            for(int j=0;j<n;j++){
                if(i!=j && arr[i]==arr[j]){
                    count++;
                }
            }
            if(count==1){
                System.out.println("the non repeating elements are :"+arr[i]);
            }
        }
    }
}