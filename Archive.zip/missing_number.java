// // // import java.util.*;
// // // class missing_number{
// // //     public static void main(String[] args) {
// // //         Scanner Sc=new Scanner(System.in);
// // //     System.out.println("enter the number: ");
// // //     int n=Sc.nextInt();
// // //     int arr[]=new int[n];
// // //     System.out.println("enter the elements: ");
// // //     for(int i=0;i<n;i++){
// // //         arr[i]=Sc.nextInt();  
// // //     }
// // //     int sum=0;
// // //     for(int i=0;i<n;i++){
// // //         sum=sum+arr[i];
// // //     }
    
// // //     System.out.println("the missign number is: ");
// // //     int he=(n*(n+1))/2;
// // //     int res=he-sum;
// // //     System.out.println(res);
// // //     }
// // // }



// // import java.util.*;
// // class missing_number{
// //     public static void main(String[] args) {
// //         Scanner Sc=new Scanner(System.in);
// //     System.out.println("enter the number: ");
// //     int n=Sc.nextInt();
// //     int arr[]=new int[n];
// //     System.out.println("enter the elements: ");
// //     for(int i=0;i<n;i++){
// //         arr[i]=Sc.nextInt();  
// //     }
// //     Arrays.sort(arr);
// //     int sum=0;
// //     for(int i=0;i<n;i++){
// //         sum=sum+arr[i];
// //     }
    

// //     System.out.println("the missign number is: ");
// //     int he=(n*(n+1))/2;
// //     int res=he-sum;
// //     System.out.println(res);
// //     }
// // }






// import java.util.*;

// class missing_number{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         int max=arr[0];
//         int min=arr[0];
//         for(int i=1;i<n;i++){
//             if(arr[i]>max){
//                 max=arr[i];
//             }
//             else if(arr[i]<min){
//                 min=arr[i];
//             }
//         }

//         Arrays.sort(arr);
//         for(int i=arr[min];i<=arr[max];i++){
//             if(i!=arr[i]){
//                 System.out.println(i);
//                 break;
//             }
//         }
//     }
// }







import java.util.Scanner;
import java.util.Arrays;
class missing_number{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size :");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        Arrays.sort(arr);
        
        for(int i=0;i<=n;i++){
            if(i+1!=arr[i]){
                System.out.println(i);
            }
        }
    }
}