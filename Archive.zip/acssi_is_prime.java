// Given a string input find the characters whose ASCII values is prime number and   generate the result as follows

//   Case 1 : when string contains character whose ASCII value is prime
//   Example input 1 : WIPRO 
//   OUTPUT = IO:152
//   Explanation: in Wipro ASCII values of I and O are 73 and 79 they are prime so And it's sum = 152(73+79) so
//   OUTPUT = IO:152
// import java.util.Scanner;
// import java.util.ArrayList;
// class acssi_is_prime{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enetr the String: ");
//         String n=Sc.nextLine();
//         StringBuilder sb=new StringBuilder();
//         ArrayList<Integer>list=new ArrayList<>();
//         for(int i=0;i<n.length();i++){
//             char a=n.charAt(i);
//             if((a>='a' && a<='z') || (a>='A' && a<='z')){
//                 int ascci=(int)a;
//                 if(ascci>1){
//                     boolean isprime=false;
//                     for(int j=2;j<=Math.sqrt(ascci);j++){
//                         if(ascci%j==0){
//                             isprime=true;
//                             break;
//                         }
//                     }
//                     if(isprime){
//                         list.add(ascci);
//                         sb.append(a);
//                     }
//                 }
//             }
//         }
//         int sum=0;
//         for(int i=0;i<list.size();i++){
//             sum=sum+list.get(i);
//         }
//         System.out.println(sb.toString()+":"+sum);
//     }
// }











