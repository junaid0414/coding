// i/p: {"cricket","mom","hello","dad",""}
// o/P:mom;  //because first palindrome

// import java.util.Scanner;
// class first_palindrome_string_in_array{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n=Sc.nextInt();
//         String arr[]=new String[n];
//         Sc.nextLine();
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextLine();
//         }
//         String result=firstPalindrome(arr);
//         System.out.println("the solution is: "+result);
//     }
//     public static String firstPalindrome(String arr[]){
//         for(int i=0;i<arr.length;i++){
//             StringBuilder sb1=new StringBuilder(arr[i]);
//             sb1.reverse();
//             if(sb1.toString().equals(arr[i])){
//                 return arr[i];
//             }
//         }
//         return "";
//     }
// }
