import java.util.*;
import java.util.Arrays;
class group_anagram{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size of the string array: ");
        int n=Sc.nextInt();
        String arr[]=new String[n];
        Sc.nextLine();
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextLine();
        }

        ArrayList<ArrayList<String>> result=anagram(arr);

        for(ArrayList<String> key:result){
            System.out.println(key);
        }
    }

    public static ArrayList<ArrayList<String>> anagram(String arr[]){
        int n=arr.length;
        HashMap<String, ArrayList<String>> map=new HashMap<>();

        for(int i=0;i<n;i++){
            char sorted[]=arr[i].toCharArray();
            Arrays.sort(sorted);
            String ans=new String(sorted);

            if(!map.containsKey(ans)){
                map.put(ans,new ArrayList<>());
            }
            map.get(ans).add(arr[i]);
        }

        return new ArrayList<>(map.values());

        
    }
}