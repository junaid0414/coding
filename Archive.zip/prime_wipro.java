import java.util.Scanner;
class prime_wipro{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("ok");
        int sum=0;
        if(n>=2){
            sum=sum+arr[0]+arr[1];
        }
        for(int i=0;i<n;i++){
            if(i>=0){
                boolean prime=true;
                for(int j=2;j<=Math.sqrt(i);j++){
                    if(i%j==0){
                        prime=false;
                    }
                }
                if(prime==false && n>2){
                    System.out.println(arr[i]);
                    sum=sum+arr[i];
                }
            }
        }
        System.out.println(sum);
    }
}





