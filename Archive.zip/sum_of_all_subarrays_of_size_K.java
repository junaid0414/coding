// Input: arr[] = {1, 2, 3, 4, 5, 6}, K = 3 
// Output: 6 9 12 15 
// Explanation: 
// All subarrays of size k and their sum: 
// Subarray 1: {1, 2, 3} = 1 + 2 + 3 = 6 
// Subarray 2: {2, 3, 4} = 2 + 3 + 4 = 9 
// Subarray 3: {3, 4, 5} = 3 + 4 + 5 = 12 
// Subarray 4: {4, 5, 6} = 4 + 5 + 6 = 15

// import java.util.Scanner; //brute force approach
// public class sum_of_all_subarrays_of_size_K {
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("enter the k value: ");
//         int k=Sc.nextInt();

//         for(int i=0;i<=n-k;i++){
//             int sum=0;
//             for(int j=i;j<i+k;j++){
//                 sum=sum+arr[j];
//             }
//             System.out.println(sum);
//         }
//     }
// }




//optimise approach
// import java.util.Scanner;
// class sum_of_all_subarrays_of_size_K{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("enter the k value :");
//         int k=Sc.nextInt();
//         int sum=0;
//         for(int i=0;i<k;i++){
//             sum=sum+arr[i];
//         }
//         System.out.println(sum);
//         for(int i=k;i<arr.length;i++){
//             sum=sum-arr[i-k]+arr[i];
//             System.out.println(sum);
//         }
//     }
// }



