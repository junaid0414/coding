import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
class accenture{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        ArrayList<Integer> list=new ArrayList<Integer>();
        for(int i=0;i<n;i++){
            if(i%2==0){
                list.add(arr[i]);
            }
        }
        ArrayList<Integer> list1=new ArrayList<Integer>();
        for(int i=0;i<n;i++){
            if(i%2!=0){
                list1.add(arr[i]);
            }
        }
        Collections.sort(list);
        Collections.sort(list1);

        System.out.println(list);
        System.out.println(list1);

        if(list.size()>2 && list1.size()>2){
        int q=list.get(1);
        int e=list1.get(1);

        int sum=q+e;
        System.out.println("the sum is: "+sum);
        }

        else if(list.size()==2 && list1.size()==2){
            int u=list.get(0);
            int m=list1.get(0);
        }
        
        else if(list.size()==2 && list1.size()>2){
            int hy=list.get(0);
            int gh=list1.get(1);

            int sum5=hy+gh;

            System.out.println("the sum is: "+sum5);
        }

        else if(list.size()>2 && list1.size()==2){
            int ij=list.get(1);
            int lm=list1.get(0);

            int sum6=ij+lm;

            System.out.println("the sum is: "+sum6);
        }
    }
}