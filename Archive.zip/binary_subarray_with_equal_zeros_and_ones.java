import java.util.Scanner;
class binary_subarray_with_equal_zeros_and_ones{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("Entr the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int max=0;
        for(int i=0;i<n;i++){
            int zero=0;
            int one=0;
            for(int j=i;j<n;j++){
                if(arr[j]==0){
                    zero++;
                }
                else{
                    one++;
                }
                if(zero==one){
                    max=Math.max(max,j-i+1);
                }
            }
        }
        System.out.println("max is : "+max);
    }
}