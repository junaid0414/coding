import java.util.Scanner;
class handshakes{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        int n=Sc.nextInt();

        int ans=(n-1)*n/2;
        System.out.println(ans);
    }
}