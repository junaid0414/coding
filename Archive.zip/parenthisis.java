import java.util.Scanner;
import java.util.Stack;
class Main{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        String n=Sc.nextLine();
        
        boolean result=paren(n);
        System.out.println(result);
    }
    public static boolean paren(String n){
        Stack<Character> stack=new Stack<>();
        for(int i=0;i<n.length();i++){
            if(n.charAt(i)=='(' || n.charAt(i)=='[' || n.charAt(i)=='{'){
                stack.push(n.charAt(i));
            }
            else{
                if(stack.isEmpty()){
                    return false;
                }
                char top=stack.pop();
                if((n.charAt(i)==')' && top!='(') || (n.charAt(i)==']' && top!='[') || (n.charAt(i)=='{' && top!='}')){
                return false;
                }
            }
            
        }
        return stack.isEmpty();
    }
}
