import java.util.Scanner;
class sliding_window{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("enter the k value: ");
        int k=Sc.nextInt();
        int result=sliding(arr,n,k);
        System.out.println("the result is: "+result);
    }
    public static int sliding(int arr[],int n,int k){
        int sum=0;
        int maxsum=0;

        for(int i=0;i<k;i++){
            sum=sum+arr[i];
        }
        for(int i=k;i<arr.length;i++){
            sum=sum-arr[i-k]+arr[i];
            maxsum=Math.max(sum,maxsum);
        }
        return maxsum;
    }
}










// import java.util.Scanner;
// class sliding_window{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size :");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         int maxsum=0;
//         System.out.println("Enter the k value: ");
//         int k=Sc.nextInt();
//         int sum=0;
//         for(int i=0;i<k;i++){
//             sum=sum+arr[i];
//         }
//         for(int i=k;i<=arr.length;i++){
//             sum=sum-arr[i-k]+arr[i];
//             maxsum=Math.max(sum,maxsum);
//         }
//         System.out.println(maxsum);
//     }
// }




// import java.util.Scanner;
// class sliding_window{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size :");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         int maxsum=0;
//         System.out.println("Enter the k value: ");
//         int k=Sc.nextInt();
//         int sum=0;
//         for(int i=0;i<k;i++){
//             sum=sum+arr[i];
//             System.out.println(sum);
//         }
//         for(int i=k;i<=arr.length;i++){
//             sum=sum-arr[i-k]+arr[i];
//             System.out.println(sum);
//         }
//     }
// }








// import java.util.Scanner;
// import java.util.LinkedHashSet;
// class sliding_window{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the string: ");
//         String n=Sc.nextLine();

//         char arr[]=n.toCharArray();

//         LinkedHashSet<Character> set=new LinkedHashSet<>();
//         for(int i=0;i<arr.length;i++){
//             set.add(arr[i]);
//         }
//         System.out.println(set);
//     }
// }