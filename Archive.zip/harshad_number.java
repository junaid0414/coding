import java.util.Scanner;
class harshad_number{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        int sum=0;
        while(n!=0){
            int digit=n%10;
            sum=sum+digit;
            n/=10;
        }
        if(n%sum==0){
            System.out.println("harshad number");
        }
        else{
            System.out.println("Not a harshad number");
        }
    }
}