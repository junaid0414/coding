// import java.util.Scanner;
// class letter_reverse_important{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the string: ");
//         String n=Sc.nextLine();
//         StringBuilder sb=new StringBuilder();
//         String arr[]=n.split(" +"); // " +" this means the space will be single or many sothat we will add +
//         for(int i=arr.length-1;i>=0;i--){
//             sb.append(arr[i]);
//             sb.append(" ");
//         }
//         System.out.println(sb.toString().trim());
//     }
// }







