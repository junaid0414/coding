import java.util.Scanner;
class multiply_two_string{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the first string: ");
        String n=Sc.nextLine();
        System.out.println("Enter the second string: ");
        String n1=Sc.nextLine();

        String result=mul(n,n1);
        System.out.println("the result is: "+result);
    }
     public static String mul(String n ,String n1){
        int n3=Integer.parseInt(n);
        int n4=Integer.parseInt(n1);

        int n5=n3*n4;
        String n6=String.valueOf(n5);//this line is converting integer to string
        return n6;
    }
}