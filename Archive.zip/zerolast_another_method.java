import java.util.Scanner;
class zerolast_another_method{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int i,j=0;
        for(i=0;i<n;i++){
            if(arr[i]!=0){
                arr[j]=arr[i];
                j=j+1;
            }
        }
        for(i=j;i<n;i++){
            arr[j]=0;
        }
        for(j=0;j<n;j++){
            System.out.println(arr[j]);
        }
    }
}