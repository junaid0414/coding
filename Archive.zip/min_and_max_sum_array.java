import java.util.Scanner;
import java.util.Arrays;
class min_and_max_sum_array{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println(" Enter the elementS: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        Arrays.sort(arr);
        int min=0;
        for(int i=0;i<n-1;i++){
            min=min+arr[i];
        }

        int max=0;
        for(int i=1;i<n;i++){
            max=max+arr[i];
        }

        System.out.println(min+" "+max);
    }
}
