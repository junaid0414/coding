import java.util.Scanner;
class avgarray{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements in the array: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int sum=0;
        for(int i=0;i<n;i++){
            sum=sum+arr[i];
        }
        int avg=sum/n;

        System.out.println("the avg of the array is: ");
        System.out.println(avg);
    }
}








