// Input:
// N = 8
// A[] = {15,-2,2,-8,1,7,10,23}
// Output: 5
// Explanation: The largest subarray with
// sum 0 will be -2 2 -8 1 7.


// import java.util.Scanner;
// class largest_subarray_sum_with_zero{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("entert he k value: ");
//         int k=Sc.nextInt();

//         int result=array(arr,n,k);
//         System.out.println("the results are: "+result);
//     }
//     public static int array(int arr[],int n,int k){
//     int max=0;
//     for(int i=0;i<n;i++){
//         int sum=0;
//         for(int j=i;j<n;j++){
//             sum=sum+arr[j];
//             if(sum==0){
//                 max=Math.max(max,j-i+1);
//             }
//         }
//     }
//     return max;
// }
// }







import java.util.Scanner;
class largest_subarray_sum_with_zero{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the eleemtns: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("enter the k value: ");
        int k=Sc.nextInt();
        int max=Integer.MIN_VALUE;
        for(int i=0;i<n;i++){
            int sum=0;
            for(int j=i;j<n;j++){
                sum=sum+arr[j];
                if(sum==0){
                    int length=j-i+1;
                    if(length>max){
                        max=length;
                    }
                }
            }
        }
        System.out.println(max);
    }
}