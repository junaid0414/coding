import java.util.Scanner;
class max_element_in_subarray{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        for(int i=0;i<n;i++){
            int max=arr[i];
            for(int j=i;j<n;j++){
                if(arr[j]>max){
                    max=arr[j];
                }
                System.out.println("the maximum element "+i+" "+j+" : "+max);
            }
            
        }

    }
}