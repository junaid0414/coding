// i/p: aarthaaaa of star is ape
// o/P: 4 //length of the string
//      24//characters in the string

// import java.util.Scanner;
// class accenture_problem{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the string: ");
//         String n=Sc.nextLine().trim();
//         String words[]=n.split(" ");

//         int count=-1;
//         for(String word:words){
//             count++;
//         }
//         System.out.println(count);
//         int count1=0;
//         for(int i=0;i<n.length();i++){
//             if((n.charAt(i)>='a' && n.charAt(i)<='z') || (n.charAt(i)>='A' && n.charAt(i)<='Z') || n.charAt(i)==' '){
//                 count1++;
//             }
//         }
//         System.out.println(count1);
//     }
// }





