import java.util.Scanner;
class mex_number{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int result=mex(n,arr);
        System.out.println("The result is: "+result);
    }
    public static int mex(int n,int arr[]){
        for(int i=0;i<n;i++){
            if(arr[i]!=i){
                return i;
            }
        }
        return -1;
    }
}