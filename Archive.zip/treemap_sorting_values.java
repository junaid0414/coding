import java.util.*;

class Solution {
    public int[] frequencySort(int[] nums) {
        int n = nums.length;
        HashMap<Integer, Integer> map = new HashMap<>();
        
        // Count the frequency of each element
        for (int i = 0; i < n; i++) {
            map.put(nums[i], map.getOrDefault(nums[i], 0) + 1);
        }
        
        Integer[] temp = new Integer[n];
        for (int i = 0; i < n; i++) {
            temp[i] = nums[i];
        }
        
        // Sort the elements based on their frequencies and values
        Arrays.sort(temp, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                if (map.get(a).equals(map.get(b))) {
                    return b - a;  // If frequencies are the same, sort by value in descending order
                }
                return map.get(a) - map.get(b);  // Otherwise, sort by frequency in ascending order
            }
        });
        
        // Update the original array with the sorted elements
        for (int i = 0; i < n; i++) {
            nums[i] = temp[i];
        }
        
        return nums;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Read the input array size
        System.out.print("Enter the number of elements: ");
        int size = scanner.nextInt();
        
        // Read the input array elements
        int[] nums = new int[size];
        System.out.println("Enter the elements:");
        for (int i = 0; i < size; i++) {
            nums[i] = scanner.nextInt();
        }
        
        // Create an instance of the Solution class and call the frequencySort method
        Solution solution = new Solution();
        int[] sortedNums = solution.frequencySort(nums);
        
        // Print the sorted array
        System.out.println("Sorted array by frequency:");
        for (int num : sortedNums) {
            System.out.print(num + " ");
        }
    }
}
