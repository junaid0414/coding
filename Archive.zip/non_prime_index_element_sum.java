import java.util.Scanner;
class non_prime_index_element_sum{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("nter the elements :");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int sum=0;
        for(int i=0;i<n;i++){
            boolean isprime=false;
            if(i<2){
                isprime=true;
            }
            else{
                for(int j=2;j<=Math.sqrt(i);j++){
                    if(i%j==0){
                        isprime=true;
                    }
                }
            }
            if(isprime==false){
                arr[i]=0;
            }
        }
        for(int i=0;i<n;i++){
            sum=sum+arr[i];
        }
        System.out.println("the sum is: "+sum);
    }
}








// import java.util.*;
// class non_prime_index_element_sum{
//   public static void main(String args[]){
// Scanner sc = new Scanner(System.in);
// String input = sc.nextLine();

// StringBuilder sb = new StringBuilder(input);
// sb.reverse();
// String reversed = sb.toString();


//     HashMap<String, String> map = new HashMap<>();
//     map.put("65", "A");
//     map.put("66", "B");
//     map.put("67", "C");
//     map.put("68", "D");
//     map.put("69", "E");
//     map.put("70", "F");
//     map.put("71", "G");
//     map.put("72", "H");
//     map.put("73", "I");
//     map.put("74", "J");
//     map.put("75", "K");
//     map.put("76", "L");
//     map.put("77", "M");
//     map.put("78", "N");
//     map.put("79", "O");
//     map.put("80", "P");
//     map.put("81", "Q");
//     map.put("82", "R");
//     map.put("83", "S");
//     map.put("84", "T");
//     map.put("85", "U");
//     map.put("86", "V");
//     map.put("87", "W");
//     map.put("88", "X");
//     map.put("89", "Y");
//     map.put("90", "Z");
//     map.put("97", "a");
//     map.put("98", "b");
//     map.put("99", "c");
//     map.put("100", "d");
//     map.put("101", "e");
//     map.put("102", "f");
//     map.put("103", "g");
//     map.put("104", "h");
//     map.put("105", "i");
//     map.put("106", "j");
//     map.put("107", "k");
//     map.put("108", "l");
//     map.put("109", "m");
//     map.put("110", "n");
//     map.put("111", "o");
//     map.put("112", "p");
//     map.put("113", "q");
//     map.put("114", "r");
//     map.put("115", "s");
//     map.put("116", "t");
//     map.put("117", "u");
//     map.put("118", "v");
//     map.put("119", "w");
//     map.put("120", "x");
//     map.put("121", "y");
//     map.put("122", "z");





// StringBuilder result = new StringBuilder();

// for (int i = 0; i < reversed.length(); i += 2) {
//     String pair = reversed.substring(i, i + 2);
//     if (map.containsKey(pair)) {
//         result.append(map.get(pair));
//     }
// }

// System.out.println(result.toString());
//   }
// }









// Problem Statement : Sunder Pichai, who is working at a software company forgot the password of his Linkedin Account. But he knows the ASCII values of his password in reverse order. Help him to find the password.



// To decode the password, first reverse the string of digits, then successively pick valid values from the string and convert them to their ASCII equivalents. Some of the values will have two digits, and others three. Use the ranges of valid values when decoding the string of digits.



// Some of the ASCII values are given with their characters:

//  The ASCII value of A to Z is 65 to 90.

//  The ASCII value of a to z is 97 to 122.

//  The ASCII value of space characters is 32.

// Note: The password only has alphabets and blank spaces.



// Given a string , decode the password by following the steps mentioned above.



// Constraints:



//    1<= |s| <=10^5
//    s[i] is an ascii character in the range [A-Za-z] or a space character


// Sample Input :

// 796115110113721110141108



// Sample Output :

// PrepInsta



// Explanation 

// The reversed string will be 801141011127311011511697, which if analysed as ascii will be “PrepInsta”


// Sample Input 1:

// 670219986


// Sample Output 1:

// DcxL


// Sample Input 2:

// 5678911401601


// Sample Output 2:

// jhwWA


// Sample Input 3:

// 787968021


// Sample Output 3:

// xVaW


// Sample Input 4:

// 796115110113721110141108


// Sample Output 4:

// PrepInsta














//problem 2



// Problem Statement :

// In the world war, the denizens of the Marvel Universe are forced to pick sides when KingA and KingB come to blows over ideological differences. The government decides to push for the Hero Registration Act, a law that limits a hero’s actions. This results in a division in The Soldiers.KingB stands with this Act, claiming that their actions must be kept in check otherwise cities will continue to be destroyed, but KingA feels that saving the world is daring enough and that they cannot rely on the government to protect the world. And here the civil war begins. They are trying make their team stronger by adding more Soldiers to their team. There are N Soldiers lined up.

// Rules to add avenger to their team-

// Any team can start first. But they will alternatively only.
// They can select avenger from any side. But if they start from one side they can’t move to other side in current chance.
// They can select consecutive Soldiers as many they want.
// They will stop only when all the Soldiers are part of either side.
// Every Avenger has a power associated with him
// There are some spurious Soldiers who will decrease the overall power of the team.
// Both teams will select players optimally. Find the difference of powers of the two teams



// Constraints

// 1<= N <= 10^6

// -10^9 <= p[i] <= 10^9



// Input

// First line contains an integer denoting the number of Soldiers(N).

// Next lines contain N space separated values denoting power of every avenger(P[i]).



// Output

// Print the difference of the powers of teams –

// Time Limit (secs) 1



// Examples :

// Input

// 5

// 2 -7 8 -1 20

// Output

// 2




// Sample Input 1:

// 5

// 2 -7 8 -1 20


// Sample Output 1:

// 2


// Sample Input 2:

// 4

// 4 -21 30 31


// Sample Output 2:

// 24


// Sample Input 3:

// 6

// 1 5 -2 22 33 -7


// Sample Output 3:

// 4


// Sample Input 4:

// 4

// 2 -1 -2 -3


// Sample Output 4:

// 6