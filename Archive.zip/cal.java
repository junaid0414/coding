// import java.util.Scanner;
// class calibrant_reverse_string{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the string: ");
//         String n=Sc.nextLine();


//     }
// }


// import java.util.Scanner;
// public class cal{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         String n=Sc.nextLine();
//         String input2=Sc.nextLine();
//         if(n.contains(input2)){
//             System.out.println("1");
//         }
//         else{
//             System.out.println("-1");
//         }
//     }
// }






import java.util.Scanner;
class cal{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enetr teh sie: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enetr the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        
    }
}