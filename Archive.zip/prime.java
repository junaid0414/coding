import java.util.Scanner;
class prime{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        int count=0;
        if(n>1){
            for(int i=1;i<=n;i++){
                if(n%i==0){
                    count++;
                }
            }
        }
        if(count ==2){
            System.out.println("Prime");
        }
        else{
            System.out.println("not a prime");
        }
        
    }
}






