// import java.text.DecimalFormat;
// import java.util.Scanner;
// class median_of_sorted_arrays{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the array size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }

//         System.out.println("enter the array size: ");
//         int n1=Sc.nextInt();
//         int arr1[]=new int[n1];
//         System.out.println("enter the elements: ");
//         for(int i=0;i<n1;i++){
//             arr1[i]=Sc.nextInt();
//         }

//         int l=n+n1;
//         int temp[]=new int[l];
//         for(int i=0;i<n;i++){
//             temp[i]=arr[i];
//         }
//         for(int i=0;i<n1;i++){
//             temp[n+i]=arr1[i];
//         }
//         for(int i=0;i<l;i++){
//             for(int j=i+1;j<l;j++){
//                 if(temp[i]>temp[j]){
//                     int swap=temp[i];
//                     temp[i]=temp[j];
//                     temp[j]=swap;
//                 }
//             }
//         }
//         float sum=0;
//         for(int i=0;i<l;i++){
//             sum=sum+temp[i];
//         }
//         System.out.println("the sum is: "+sum);


//         float z=temp.length;
//         System.out.println("the length of the array is: ");
//         System.out.println(z);

//         float q=sum/z;
//         System.out.println("the final is: "+q);
//     }
// }



import java.util.ArrayList;
import java.util.Scanner;
import java.util.Collections;
class median_of_sorted_arrays{
    public static void main(String[] args) {
        ArrayList<Integer> arr=new ArrayList<>();
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the arrayd ize:" );
        int n=Sc.nextInt();
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            int n1=Sc.nextInt();
            arr.add(n1);
        }
        ArrayList<Integer> arr1=new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the arrayd ize:" );
        int n2=sc.nextInt();
        System.out.println("enter the elements: ");
        for(int i=0;i<n2;i++){
            int n3=sc.nextInt();
            arr1.add(n3);
        }
        ArrayList <Integer> merge=new ArrayList<>();
        merge.addAll(arr);
        merge.addAll(arr1);
        Collections.sort(merge);
        System.out.println(merge);
        int z=merge.size();
        System.out.println("the size is: "+z);

        int sum=0;
        for(int i=0;i<merge.size();i++){
            sum=sum+merge.get(i);
        }
        System.out.println("the first new"+sum);

        System.out.println("the median is: ");
        System.out.println(sum/z);
    }
}