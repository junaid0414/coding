//n1=3,n2=12 ,gcd=3
import java.util.Scanner;
class hcf_or_gcd{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the first number: ");
        int n1=Sc.nextInt();
        System.out.println("Enter the seocd number: ");
        int n2=Sc.nextInt();

        int gcd=0;
        for(int i=1;i<=Math.min(n1,n2);i++){
            if(n1%i==0 && n2%i==0){
                gcd=i;
            }
        }
        System.out.println(gcd);
    }
}



