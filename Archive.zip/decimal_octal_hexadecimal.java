import java.util.Scanner;
class decimal_octal_hexadecimal{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the integer");
        int n=Sc.nextInt();
        //the below methods will convert integer to deciaml and octal and hexadeciaml
        System.out.printf("%d",n);//decimal
        System.out.printf("\n%o",n);//octal
        System.out.printf("\n%h",n);//hexadecimal

    }
}