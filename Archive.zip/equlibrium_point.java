// // Input: arr[] = [1, 3, 5, 2, 2]
// // Output: 3 
// import java.util.Scanner;
// class equlibrium_point{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         int result=equilibrium(n,arr);
//         System.out.println("the result is: "+result);
//     }
//     public static int equilibrium(int n,int arr[]){
//         int sum=0;
//         for(int i=0;i<n;i++){
//             sum=sum+arr[i];
//         }
//         int sum1=0;
//         for(int i=0;i<n;i++){
//             sum=sum-arr[i];
//             if(sum1==sum){
//                 return i+1;
//             }
//             sum1=sum1+arr[i];
//         }
//         return -1;
//     }
// }







import java.util.Scanner;
class equlibrium_point{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        int n=Sc.nextInt();
        int arr[]=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int sum=0;
        for(int i=0;i<n;i++){
            sum=sum+arr[i];
        }

        int sum1=0;
        for(int i=0;i<n;i++){
            sum=sum-arr[i];
            if(sum1==sum){
                System.out.println(i+1);
                break;
            }
            sum1=sum1+arr[i];
        }
    }
}
