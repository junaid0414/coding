// // import java.util.Scanner;
// // class zerolast{
// //     public static void main(String args[]){
// //         Scanner Sc=new Scanner(System.in);
// //         System.out.println("enter the array size: ");
// //         int n=Sc.nextInt();
// //         int arr[]=new int[n];
// //         System.out.println("enter the elemnts int he array: ");
// //         for(int i=0;i<n;i++){
// //             arr[i]=Sc.nextInt();
// //         }
// //         int nonzero=0;
// //         int zero=0;

// //         while(nonzero<n){
// //             if(arr[nonzero]!=0){
// //                 int temp=arr[nonzero];
// //                 arr[nonzero]=arr[zero];
// //                 arr[zero]=temp;
// //                 nonzero++;
// //                 zero++;
// //             }
// //             else{
// //                 nonzero++;
// //             }
// //         }    
// //         System.out.println("the last elemetn is: ");
// //         for(int i=0;i<n;i++){
// //             System.out.println(arr[i]);
// //         }
// //     }
// // }


// import java.util.Scanner;
// class zerolast{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the array size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enetr the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
        

//         int nonzero=0;
//         int zero=0;

//         while(nonzero<n){                          //                      N
//             if(arr[nonzero]!=0){                   //[4, 5, 1, 9, 0, 5, 0, 0].
//                 int temp=arr[nonzero];             //                   Z
//                 arr[nonzero]=arr[zero];
//                 arr[zero]=temp;
//                 nonzero++;
//                 zero++;
//             }
//             else{
//                 nonzero++;
//             }
//         }
//         System.out.println("the sorted array is: ");
//         for(int i=0;i<n;i++){
//             System.out.println(arr[i]+" ");
//         }
//     }
// }

// // !=





// // System.out.println("enter the move element: ");
// //         int move=Sc.nextInt();








import java.util.Scanner;
class zerolast{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enetr the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int zero=0;
        int nonzero=0;
        while(nonzero<n){
            if(arr[nonzero]!=0){
                int temp=arr[nonzero];
                arr[nonzero]=arr[zero];
                
                arr[zero]=temp;
                nonzero++;
                zero++;
            }
            else{
                nonzero++;
            }
        }
        System.out.println("The array is: ");
        for(int i=0;i<n;i++){
            System.out.println(arr[i]+" ");
        }
    }
}