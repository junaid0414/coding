// import java.util.Scanner;
// class remove_delete_character{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the string: ");
//         String n=Sc.nextLine();
//         System.out.println("Enter the chaacter to remove: ");
//         char point=Sc.next().charAt(0);
//         StringBuilder sb=new StringBuilder();
//         for(int i=0;i<n.length();i++){
//             char letter=n.charAt(i);
//             if(letter!=point){
//                 sb.append(letter);
//             }
//         }
//         System.out.println(sb);
//     }
// }




