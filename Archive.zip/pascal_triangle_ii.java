// import java.util.Scanner;
// class pascal_triangle_ii{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the rows: ");
//         int n=Sc.nextInt();
//         System.out.println("Enter the columns");
//         int r=Sc.nextInt();

//         long res=1;
//         for(int i=1;i<=r-1;i++){
//             res=res*(n-i);
//             res=res/(i+1);
//         }
//         System.out.println(res);
//     }
// }







import java.util.*;
class pascal_triangle_ii{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        int n=Sc.nextInt();
        ArrayList<ArrayList<Integer>> pascal=new ArrayList<>();
        for(int row=1;row<=n;row++){
            ArrayList<Integer> list=new ArrayList<>();
            long ans=1;
            list.add(1);
            for(int col=1;col<row;col++){
                ans=ans*(row-col);
                ans=ans/col;
                list.add((int) ans);
            }
            pascal.add(list);
        }
        
        for(ArrayList<Integer> key:pascal){
            for(int ele:key){
                System.out.print(ele);
            }
            System.out.println();
        }
    }
}