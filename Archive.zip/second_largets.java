import java.util.*;
class second_largest{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int result=second(n,arr);
        System.out.println("the result is: "+result);
    }
    public static int second(int n,int arr[]){
        HashSet<Integer> set=new HashSet<>();
        for(int i=0;i<n;i++){
            set.add(arr[i]);
        }
        ArrayList<Integer> list=new ArrayList<>(set);
        Collections.sort(list);        
        return list.get(list.size() - 2);
    }
}