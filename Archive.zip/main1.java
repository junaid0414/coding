import java.util.*;
class main1{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n1=Sc.nextInt();
        int arr1[]=new int[n1];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n1;i++){
            arr1[i]=Sc.nextInt();
        }
        
        System.out.println("Enter the size1: ");
        int n2=Sc.nextInt();
        int arr2[]=new int[n2];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n2;i++){
            arr2[i]=Sc.nextInt();
        }
        
        HashMap<Integer,Integer> map1=new HashMap<>();
        HashMap<Integer,Integer> map2=new HashMap<>();
        
        for(int i=0;i<n1;i++){
            if(map1.containsKey(arr1[i])){
                map1.put(arr1[i],map1.get(arr1[i])+1);
            }
            else{
                map1.put(arr1[i],1);
            }
        }
        
        for(int i=0;i<n2;i++){
            if(map2.containsKey(arr2[i])){
                map2.put(arr2[i],map2.get(arr2[i])+1);
            }
            else{
                map2.put(arr2[i],1);
            }
        }
        
        if(map1.containsKey(map2)){
            System.out.println("true");
        }
        else{
            System.out.println("False");
        }
    }
}