// 5
// enter the elements: 
// 2
// 3
// 1
// 0
// 4
// the op is: 
// 3
// 2
// 0
// 1
// 4
import java.util.Scanner;
class inverse{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int arr1[]=new int[n];
        for(int i=0;i<n;i++){
            int x=arr[i];
            arr1[x]=i;
        }
        System.out.println("the resultant array is: ");
        for(int i=0;i<n;i++){
            System.out.println(arr[i]);
        }
    }
}