import java.util.Scanner;
class prime_in_array{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enetr the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        for(int i=0;i<n;i++){
            if(arr[i]>1){
                boolean prime=true;
                for(int j=2;j<=Math.sqrt(arr[i]);j++){
                    if(arr[i]%j==0){
                        prime=false;
                    }
                }
                if(prime==true){
                    System.out.println(arr[i]);
                }
            }
        }
    }
}





