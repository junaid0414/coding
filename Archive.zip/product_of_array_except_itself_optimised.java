//optimised approach
//https://www.youtube.com/watch?v=10NJzNaSsrg
//go and check this video
import java.util.Scanner;
public class product_of_array_except_itself_optimised {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int prefix[]=new int [n];
        int suffix[]=new int [n];

        prefix[0]=1;
        for(int i=1;i<n;i++){
            prefix[i]=prefix[i-1]*arr[i-1];
        }

        suffix[n-1]=1;
        for(int i=n-2;i>=0;i--){
            suffix[i]=suffix[i+1]*arr[i+1];
        }

        int total[]=new int[n];
        for(int i=0;i<n;i++){
            total[i]=prefix[i]*suffix[i];
        }

        for(int i=0;i<n;i++){
            System.out.println(total[i]);
        }
    }
}