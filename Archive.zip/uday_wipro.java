// import java.util.Scanner;
// class uday_wipro{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         int input1=Sc.nextInt();
//         int input2=Sc.nextInt();
//         int input3=Sc.nextInt();
//         int input4=Sc.nextInt();

//         int result=findPIN(input1,input2,input3,input4);
//         System.out.println(result);
//     }
//     public static int findPIN(int input1,int input2,int input3,int input4){
//         int max1=Integer.MIN_VALUE;
//         int min1=Integer.MAX_VALUE;
//         while(input1!=0){
//             int digit=input1%10;
//             if(digit>max1){
//                 max1=digit;
//             }
//             if(digit<min1){
//                 min1=digit;
//             }
//             input1=input1/10;
//         }

//         int max2=Integer.MIN_VALUE;
//         int min2=Integer.MAX_VALUE;
//         while(input2!=0){
//             int digit=input2%10;
//             if(digit>max2){
//                 max2=digit;
//             }
//             if(digit<min2){
//                 min2=digit;
//             }
//             input2=input2/10;
//         }

//         int max3=Integer.MIN_VALUE;
//         int min3=Integer.MAX_VALUE;
//         while(input3!=0){
//             int digit=input3%10;
//             if(digit>max3){
//                 max3=digit;
//             }
//             if(digit<min3){
//                 min3=digit;
//             }
//             input3=input3/10;
//         }
//         int x=((max1*min1)*(max2*min2)* (max3*min3))-input4;
//         return x;
//     }
// }


