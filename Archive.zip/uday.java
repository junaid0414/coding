import java.util.Scanner;

public class uday {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int input1 = sc.nextInt();
        int input2 = sc.nextInt();
        int input3 = sc.nextInt();

        int result=ans(input1,input2,input3);
        System.out.println(result);
    }
    public static int ans(int input1,int input2,int input3){
        int max1 = Integer.MIN_VALUE;
        int max2 = Integer.MIN_VALUE;
        int max3 = Integer.MIN_VALUE;

        int temp = input1;
        while (temp != 0) {
            int digit = temp % 10;
            if (digit > max1) {
                max1 = digit;
            }
            temp /= 10;
        }
        temp = input2;
        while (temp != 0) {
            int digit = temp % 10;
            if (digit > max2) {
                max2 = digit;
            }
            temp /= 10;
        }
        temp = input3;
        while (temp != 0) {
            int digit = temp % 10;
            if (digit > max3) {
                max3 = digit;
            }
            temp /= 10;
        }
        int min1 = Integer.MAX_VALUE;
        temp = input1;
        while (temp != 0) {
            int digit = temp % 10;
            if (digit < min1) {
                min1 = digit;
            }
            temp /= 10;
        }

        int min2 = Integer.MAX_VALUE;
        temp = input2;
        while (temp != 0) {
            int digit = temp % 10;
            if (digit < min2) {
                min2 = digit;
            }
            temp /= 10;
        }

        int min3 = Integer.MAX_VALUE;
        temp = input3;
        while (temp != 0) {
            int digit = temp % 10;
            if (digit < min3) {
                min3 = digit;
            }
            temp /= 10;
        }
        int ans = (max1 + max2 + max3) - (min1 + min2 + min3);
        return -ans;
    }
}