import java.util.Scanner;
class digit_largest_smallest{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the element`: ");
        int n=Sc.nextInt();
        int largest=0,smallest=9;
        while(n!=0){
            int digit=n%10;
            if(digit>largest){
                largest=digit;
            }
            if(digit<smallest){
                smallest=digit;
            }
            n/=10;
        }
        System.out.println(smallest);
        System.out.println(largest);
    }
}