import java.util.Scanner;
class most_repeated_element{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elemetns: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int maxcount=0;
        int repeated=0;
        for(int i=0;i<n;i++){
            int count=0;
            for(int j=i+1;j<n;j++){
                if(arr[i]==arr[j]){
                    count++;
                }
            }
            if(count>maxcount){
                maxcount=count;
                repeated=arr[i];
            }
        }
        System.out.println("the most repeated element is: "+repeated);
    }
}