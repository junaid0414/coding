import java.util.Scanner;
import java.util.Arrays;
class boats_to_save_people{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elemtns: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("the limit is: ");
        int limit=Sc.nextInt();
        System.out.println("the limit is : ");
        int result=save(n,arr,limit);
        System.out.println("the result is: "+result);
    }
    public static int save(int n,int arr[],int limit){
        Arrays.sort(arr);

        int l=0;
        int r=n-1;

        int count=0;

        while(l<=r){
            int total=arr[r]+arr[l];
            if(total>limit){
                r--;
            }
            else{
                r--;
                l++;
            }
            count++;
        }
        return count;
    }
}