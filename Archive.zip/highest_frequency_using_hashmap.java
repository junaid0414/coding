import java.util.Scanner;
import java.util.HashMap;
class highest_frequency_using_hashmap{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elments: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        HashMap<Integer,Integer> map=new HashMap<>();
        for(int i=0;i<n;i++){
            if(map.containsKey(arr[i])){
                map.put(arr[i],map.get(arr[i])+1);
            }
            else{
                map.put(arr[i],1);
            }
        }
        int max=Integer.MIN_VALUE;
        int element=-1;
        for(int key:map.keySet()){
            if(map.get(key)>max){
                max=map.get(key);
                element=key;
            }
        }
        System.out.println(element);
    }
}
