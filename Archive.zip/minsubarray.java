import java.util.Scanner;
class minsubarray{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the array size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements in the array :");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int minsum=0;
        for(int i=0;i<n;i++){
            int sum=0;
            for(int j=i;j<n;j++){
                sum=sum+arr[j];
                if(minsum>sum){
                    minsum=sum;
                }
            }
        }
        System.out.println("the minsum is: "+minsum);
    }
}