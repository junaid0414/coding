import java.util.Scanner;
class decimal_to_octal{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        String rem="";

        while(n>=1){
            int x=n%8;
            n=n/8;
            rem=x+rem;
        }
        System.out.println("the remainder is: "+rem);
    }
}