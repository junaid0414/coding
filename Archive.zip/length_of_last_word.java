// import java.util.Scanner;
// class length_of_last_word{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the string: ");
//         String n=Sc.nextLine().trim();
//         int count=0;
//         for(int i=n.length()-1;i>=0;i--){
//             if(n.charAt(i)!=' '){
//                 count++;
//             }
//             else{
//                 break;
//             }
//         }
//         System.out.println(count);
//     }
// }












import java.util.Scanner;
class length_of_last_word{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the string: ");
        String n=Sc.nextLine().trim();
        int count=0;
        for(int i=n.length()-1;i>=0;i--){
            if(n.charAt(i)!=' '){
                count++;
            }
            else if(n.charAt(i)==' '){
                break;
            }
        }
        System.out.println(count);
    }
}