import java.util.Scanner;
class accenture_one{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the integer: ");
        int n=Sc.nextInt();

        String word=Integer.toString(n);

        StringBuilder sb=new StringBuilder(word);
        sb.reverse();
        if(sb.charAt(0)=='0'){
            sb.delete(0, 1);
        }
        String z=sb.toString();

        int x=Integer.parseInt(z);
        System.out.println("the x is: "+x);
    }
}


