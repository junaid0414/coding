import java.util.Scanner;
class evenodd{
    public static void main(String args[]){
        Scanner Sc=new Scanner(System.in);
        System.out.println("enter the array size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("enter the elements in the array: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int even=0,odd=0;
        System.out.println("the even numbers are: ");
        for(int i=0;i<n;i++){
            if(arr[i]%2==0){
                even++;
                System.out.println(arr[i]+" even numbers");
            }
        }
        System.out.println("the odd numbers are :");
        for(int i=0;i<n;i++){
            if(arr[i]%2!=0){
                odd++;
                System.out.println(arr[i]+" odd numbers");
            }
        }
        System.out.println("the even numebr are: "+even);
        System.out.println("the odd numbers are :"+odd);
    }
}
