import java.util.Scanner;
class wipro_question{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        String arr[]=new String[n];
        System.out.println("Enter the elements: ");
        Sc.nextLine();
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextLine();
        }
        String arr1[]=new String[n];
        for(int i=0;i<arr.length;i++){
            if(arr[i].contains("f") && arr[i].contains("b")){
                arr1[i]="true";
            }
            else{
                arr1[i]="false";
            }
        }
        for(int i=0;i<arr1.length;i++){
            System.out.println(arr1[i]);
        }
    }
}