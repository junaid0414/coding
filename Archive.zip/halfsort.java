//i/p: 5
//array: 2 6 7 8 9
// o/p: 2 6 9 8 7

// import java.util.Scanner;
// class halfsort{
//     public static void main(String args[]){
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("enter the array size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("enter the elements in the array :");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         for(int i=0;i<n/2;i++){
//             for(int j=0;j<n/2;j++){
//                 if(arr[j]>arr[j+1]){
//                     int temp=arr[j];
//                     arr[j]=arr[j+1];
//                     arr[j+1]=temp;
//                 }
//             }
//         }
//         for(int i=n/2;i<n-1;i++){
//             for(int j=n/2;j<n-1;j++){
//                 if(arr[j]<arr[j+1]){
//                     int temp1=arr[j];
//                     arr[j]=arr[j+1];
//                     arr[j+1]=temp1;
//                 }
//             }
//         }
//         System.out.println("the sorted array is :");
//         for(int i=0;i<n;i++){
//             System.out.println(arr[i]);
//         }
//     }
// }


// import java.util.Scanner;
// import java.util.Arrays;
// class halfsort{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         Arrays.sort(arr);
//         for(int i=0;i<n/2;i++){
//             System.out.print(arr[i]+" ");
//         }
//         for(int j=n-1;j>=n/2;j--){
//             System.out.print(arr[j]+" ");
//         }
//     }
// }
