//i/p: file_1,file_4,file_2,file_9,file_90
//o/p:90

import java.util.Scanner;
class accenture_file{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        String arr[]=new String[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextLine();
        }
        int max=Integer.MIN_VALUE;
        for(String key:arr){
            if(key.length()>=6 && key.substring(0,5).equals("file_")){
                int number=key.charAt(key.length()-1)-'0';
                if(number>max){
                    max=number;
                }
            }
        }
        System.out.println(max);
    }
}