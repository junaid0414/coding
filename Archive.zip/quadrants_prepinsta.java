import java.util.Scanner;
class quadrants_prepinsta{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the x coordinate: ");
        int x=Sc.nextInt();
        System.out.println("Enter the y coordinate: ");
        int y=Sc.nextInt();

        if(x<0 && y<0){
            System.out.println("lies in 3rd quadrant");
        }
        else if(x>0 && y>0){
            System.out.println("lies in 1st quadrant");
        }
        else if(x<0 && y>0){
            System.out.println("lies in 2nd quadrant");
        }
        else if(x>0 && y<0){
            System.out.println("lies in 4th quadrant");
        }
        else if(x==0 && y==0){
            System.out.println("origin");
        }
        
    }
}