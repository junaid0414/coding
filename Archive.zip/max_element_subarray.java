// //Brute Force approach
// import java.util.Scanner;
// class max_element_subarray{
//     public static void main(String[] args) {
//         Scanner Sc=new Scanner(System.in);
//         System.out.println("Enter the size: ");
//         int n=Sc.nextInt();
//         int arr[]=new int[n];
//         System.out.println("Enter the elements: ");
//         for(int i=0;i<n;i++){
//             arr[i]=Sc.nextInt();
//         }
//         System.out.println("Enter the k value: ");
//         int k=Sc.nextInt();
//         for(int i=0;i<n;i++){
//             int length=0;
//             for(int j=i;j<n;j++){
//                 length++;
//                 if(length==k){
//                     int max=Integer.MIN_VALUE;
//                     for(int l=i;l<=j;l++){
//                         if(arr[l]>max){
//                             max=arr[l];
//                         }
//                     }
//                     System.out.println(max);
//                 }
//             }
//         }
//     }
// }


//optimized approach
import java.util.Scanner;
class max_element_in_subarray{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        System.out.println("Enter the k value: ");
        int k=Sc.nextInt();
        for(int i=0;i<n-k;i++){
            int max=arr[i];
            for(int j=i;j<i+k;j++){
                if(arr[j]>max){
                    max=arr[j];
                }
            }
            System.out.println(max);
        }
    }
}