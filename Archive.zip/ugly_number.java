import java.util.Scanner;
class ugly_number{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n=Sc.nextInt();
        if(n<=0){
            System.out.println("It is a ugly number");
        }
        int x=0;
        while(n>1){
            if(n%2==0){
                n=n/2;
            }
            else if(n%3==0){
                n=n/3;
            }
            else if(n%5==0){
                n=n/5;
            }
            else{
                System.out.println("not a ugly number");
                x++;
                break;
            }
        }
        if(x==0){
            System.out.println("it is a ugly number");
        }
    }
}