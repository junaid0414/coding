// n=6
// arr={1,2,4,1,2,8}
// op=2
// note: 
// 1.)tou have to ignore all the negaitve amd zeros in th eprogram
// 2.)if no number is repeated the the op should be last element will be the op
// 3.)if all the elements is negative or 0 then return 0

import java.util.Scanner;
class repeated_element_from_last_wipro{
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=Sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the elements: ");
        for(int i=0;i<n;i++){
            arr[i]=Sc.nextInt();
        }
        int result=fun(n,arr);
        System.out.println(result);
    }
    public static int fun(int n,int arr[]){
        int count=0;
        for(int i=n-1;i>=0;i--){
            if(arr[i]>0){
                for(int j=i-1;j>=0;j--){
                    if(arr[j]==arr[i]){
                        return arr[i];
                    }
                }
            }
            if(arr[i]<=0){
                count++;
            }
        }
        if(count==n){
            return 0;
        }
        return arr[n-1];
    }
}